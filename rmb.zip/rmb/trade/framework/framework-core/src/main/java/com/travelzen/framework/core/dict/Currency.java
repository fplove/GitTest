package com.travelzen.framework.core.dict;

public enum Currency {
	CNY;
}
