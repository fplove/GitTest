/**
 * 
 * Description: 
 * Copyright (c) 2013
 * Company:真旅网
 * @author renshui
 * @version 1.0
 * @date 2013-5-27
 */
package com.travelzen.framework.core.dict;

public enum ChargeState {
    success, fail, pending, init, charging
}
