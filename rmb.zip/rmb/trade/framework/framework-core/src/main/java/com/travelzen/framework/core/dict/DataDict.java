/**
 * 
 */
package com.travelzen.framework.core.dict;


/**
 * @author shuiren
 *
 */
public class DataDict {
	//utf-8字符集
	public static final String CHARACTER_SET_ENCODING_UTF8 = "UTF-8";
}
