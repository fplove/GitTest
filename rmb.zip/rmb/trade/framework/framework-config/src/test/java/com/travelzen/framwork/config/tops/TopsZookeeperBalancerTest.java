package com.travelzen.framwork.config.tops;

import org.junit.Test;

public class TopsZookeeperBalancerTest {

	@Test
	public void test() throws InterruptedException {
//		System.out.println(TopsZookeeperBalancer.getRpcAddress("FlightOrderApi", "/tzns/tz"，true));
		Thread.sleep(1000000);
	
	}
}
