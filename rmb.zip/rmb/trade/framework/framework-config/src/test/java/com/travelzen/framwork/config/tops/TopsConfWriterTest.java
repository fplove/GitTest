package com.travelzen.framwork.config.tops;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.travelzen.framework.config.tops.TopsConfEnum.ConfScope;
import com.travelzen.framework.config.tops.TopsConfReader;
import com.travelzen.framework.config.tops.TopsConfWriter;

public class TopsConfWriterTest {
	private static Logger logger = LoggerFactory.getLogger(TopsConfWriterTest.class);
	
	@Test
	public void writeConfContentMap() throws Exception{
		Map<String,String> params = new HashMap<>();
		params.put("fee", "3300");
		TopsConfWriter.writeConfContent("properties/test.properties", params, ConfScope.R);
	}
	
	@Test
	public void read() throws Exception{
		System.out.println(TopsConfReader.getConfContent("properties/test.properties", "fee", ConfScope.R));
	}
}
