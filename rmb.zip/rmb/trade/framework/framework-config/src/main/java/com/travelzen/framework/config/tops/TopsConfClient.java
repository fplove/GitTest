package com.travelzen.framework.config.tops;

import java.io.ByteArrayOutputStream;
import java.util.Map;
import java.util.Properties;

import org.apache.zookeeper.CreateMode;

import com.travelzen.framework.config.tops.zk.TopsCuratorFramework;
import com.travelzen.framework.core.config.PropertiesUtil;

public class TopsConfClient {

	/**
	 * 将params中的key-value写入文件
	 * @param filePath (绝对路径)
	 * @param params
	 * @param scope
	 * @throws Exception 
	 */
	public static void writeConfContent(String filePath, Map<String, String> params) throws Exception {
		Properties properties = new Properties();
		for(Map.Entry<String, String> entry : params.entrySet()){
			properties.setProperty(entry.getKey(), entry.getValue());
		}
		writeConfContent(filePath, properties);
	}
	
	/**
	 * 将params中的properties写入文件
	 * @param filePath
	 * @param properties
	 * @param scope
	 * @throws Exception 
	 */
	public static void writeConfContent(String filePath, Properties properties) throws Exception {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		properties.store(baos, "");
		writeConfContent(filePath, baos.toByteArray());
	}
	
	/**
	 * 将data的内容写入文件
	 * @param filePath
	 * @param data
	 * @param scope
	 */
	public static void writeConfContent(String filePath, byte[] data) throws Exception{
		TopsCuratorFramework.getInstance().deleteNode(filePath);
		TopsCuratorFramework.getInstance().createNode(filePath, data, CreateMode.PERSISTENT);
	}
	
	/**
	 * 获取文件
	 * @param filePath
	 * @return
	 */
	public static Properties getConfProperties(String filePath) throws Exception{
		return PropertiesUtil.getProperty(TopsCuratorFramework.getInstance().getData(filePath));
	}
}
