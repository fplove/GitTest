framework 项目中，和 spring紧密相关类，将移动到framework-spring中， 原本 在 framework项目中的util逐渐废弃

如果其他项目只是想用和spring相关的项目， 可以只引用 framework-spring， 不用依赖 framework