package com.travelzen.framework.aop;

/**
 * 该接口用于标识可以重试执行的事务方法
 * @author renshui
 *
 */
public @interface TransactionalRetryAnnotation {

}
