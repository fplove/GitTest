package com.travelzen.framework.net.http.entity;

/**
 * 
 * @author jianyesun
 * 
 */
public class Response {

	private String command;

	private String type;

	private String result;

	public String getCommand() {
		return command;
	}

	public void setCommand(String command) {
		this.command = command;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
