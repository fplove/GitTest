package com.travelzen.framework.util;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.unidal.lookup.util.StringUtils;
import org.apache.commons.io.FileUtils;
import com.google.common.io.Files;

public class PDFUtil {
	
	private static Logger logger = LoggerFactory.getLogger(PDFUtil.class);

	/**
	 * 使用此方法要求运行环境安装GhostScript。转换使用的命令是：gs -sDEVICE=pngalpha -o %03d.png -sDEVICE=pngalpha -r144 1.pdf
	 * @param pdfFilePath
	 * @return
	 * @throws Exception
	 */
	public static List<byte[]> pdf2image(String pdfFilePath) throws Exception{
		File tempDir = null;
		try{
			tempDir = Files.createTempDir();
			Process proc = new ProcessBuilder("gs", "-sDEVICE=pngalpha", "-o", tempDir + File.separator + "%03d.png", "-sDEVICE=pngalpha", "-r144", pdfFilePath)
						       .redirectErrorStream(true)
							   .start(); 
			
			ArrayList<String> output = new ArrayList<String>();
			BufferedReader br = new BufferedReader(new InputStreamReader(proc.getInputStream()));
			String line = null;
			while ((line = br.readLine()) != null)
				output.add(line);
			
			logger.info("执行gs命令的输出：" + StringUtils.join(output, System.lineSeparator()));
			
			if (0 != proc.waitFor())
                throw new Exception("转换失败");
			
			File[] files = tempDir.listFiles();

			Arrays.sort(files, new Comparator<File>() {
				public int compare(File f1, File f2) {
					return f1.getName().compareTo(f2.getName());
				}
			});
			
			List<byte[]> images = new ArrayList<>();
			for(File file : files)
				images.add(IOUtils.toByteArray(new FileInputStream(file)));
			
			return images;
			
			
		}finally{
			if(tempDir != null)
				FileUtils.deleteDirectory(tempDir);
		}
	}
	
}
