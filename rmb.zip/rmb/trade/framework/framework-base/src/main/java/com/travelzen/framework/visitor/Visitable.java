package com.travelzen.framework.visitor;

public interface Visitable {
	 void accept(Visitor visitor);

}
