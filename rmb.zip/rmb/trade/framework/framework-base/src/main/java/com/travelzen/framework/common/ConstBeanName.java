package com.travelzen.framework.common;

public class ConstBeanName {
	
	public final static String AdvApplicationService = "appService"; 

}
