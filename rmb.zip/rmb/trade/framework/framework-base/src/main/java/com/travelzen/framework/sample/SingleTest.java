package com.travelzen.framework.sample;

public class SingleTest {
	public static void main(String args[]) {
		// SampleSingleton.getInstance();
		System.out.println("31431");

		try {
			Thread.sleep(33330);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("--------");
	}
}
