package com.travelzen.framework.enums;

/**
 * @deprecated 2014-10-15日将此类移动到common-dict项目，此类不再推荐使用
 * @see com.travelzen.tops.common.dict.core.Webapp
 */
public enum Webapp {
	biz, flight, hotel, member, pricing, provider, purchaser
}
