package com.travelzen.framework.visitor;

public interface Visitor {
	 void visit(Visitable visitable);
}
