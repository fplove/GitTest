package com.travelzen.framework.service.inter;

public interface IHelloworld {
	public String sayHello();
}
