package com.travelzen.framework.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.travelzen.framework.security.MD5;

public class MD5UtilTest {
	@Test
	public void encode() throws Exception{
//		assertEquals(MD5.encode("abc"), .MD5("abc"));
	}
}
