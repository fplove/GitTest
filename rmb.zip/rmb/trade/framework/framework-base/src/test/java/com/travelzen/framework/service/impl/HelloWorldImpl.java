package com.travelzen.framework.service.impl;

import com.travelzen.framework.service.inter.IHelloworld;

public class HelloWorldImpl implements IHelloworld{

	@Override
	public String sayHello() {
		// TODO Auto-generated method stub
		return "hello";
	}


}
