package com.travelzen.framework.util;

import org.junit.Test;

public class PDFUtilTest {

	@Test
	public void pdf2image() throws Exception{
		PDFUtil.pdf2image("/tmp/1.pdf");
	}

}
