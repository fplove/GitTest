http://wiki.fasterxml.com/JacksonInFiveMinutes



http://ginge.iteye.com/blog/763479


自定义Jackson Json的Serializer
http://fuliang.iteye.com/blog/1141293