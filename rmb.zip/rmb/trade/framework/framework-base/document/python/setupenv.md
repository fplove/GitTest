http://peak.telecommunity.com/DevCenter/EasyInstall#custom-installation-locations
