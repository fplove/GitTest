本系统规定， 一般情况下， 

vo是一个比较大的概念， 包括 dto， 数据传输对象，  view-object 视图层对象 ， mo  memory-obj 内存对象