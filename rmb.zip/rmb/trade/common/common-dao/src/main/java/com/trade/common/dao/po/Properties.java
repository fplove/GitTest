/**
 * Copyright (c) 2016, Cana and/or its affiliates. All rights reserved.
 */
package com.trade.common.dao.po;

import java.io.Serializable;

public class Properties implements Serializable {
    /**
     *版本号
     */
    private String name;

    /**
     *对应的值
     */
    private String value;

    private static final long serialVersionUID = 1L;

    /**
     *版本号
     */
    public String getName() {
        return name;
    }

    /**
     *版本号
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     *对应的值
     */
    public String getValue() {
        return value;
    }

    /**
     *对应的值
     */
    public void setValue(String value) {
        this.value = value == null ? null : value.trim();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Properties other = (Properties) that;
        return (this.getName() == null ? other.getName() == null : this.getName().equals(other.getName()))
            && (this.getValue() == null ? other.getValue() == null : this.getValue().equals(other.getValue()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
        result = prime * result + ((getValue() == null) ? 0 : getValue().hashCode());
        return result;
    }
}