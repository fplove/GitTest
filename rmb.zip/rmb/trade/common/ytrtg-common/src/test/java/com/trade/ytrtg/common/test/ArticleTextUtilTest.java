package com.trade.ytrtg.common.test;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

import com.trade.ytrtg.common.utils.ArticleTextUtil;

public class ArticleTextUtilTest {

	public static void main(String[] args) throws IOException {
		@SuppressWarnings("resource")
		RandomAccessFile raf = new RandomAccessFile(new File("/Users/meng/Documents/article.html"), "r");
		byte[] cbuf = new byte[(int) raf.length()];
		raf.readFully(cbuf);
		String article = new String(cbuf);
		
		long time = System.currentTimeMillis();
		for (int i = 0; i < 1; i++) {
			article += i;
			String left = ArticleTextUtil.leftArticle(article, 10);
			System.out.println(left);
		}
		long time2 = System.currentTimeMillis();
		System.out.println(time2 - time);
		
		
		String left2 = ArticleTextUtil.leftArticle("<table><tr><td>asf</td><td>a</td></tr><tr><td>asf</td><td>a</td></tr></table>", 5);
		System.out.println(left2);
	}

}
