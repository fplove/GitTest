package com.trade.ytrtg.common.test;

import org.junit.Test;

import com.google.gson.Gson;
import com.trade.ytrtg.common.information.dto.BasicPublishConfig;

public class TestGson {

	@Test
	public void test() {
		BasicPublishConfig b = new BasicPublishConfig();
		b.setTags(new String[]{"青铜", "白银", "黄金", "白金", "钻石", "最强王者"});
		System.out.println(new Gson().toJson(b));
	}

	@Test
	public void test2() {
		System.out.println();
	}
	
}
