package com.trade.ytrtg.common.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.trade.ytrtg.common.dto.ObjectResult;
import com.travelzen.framework.core.common.ReturnCode;
import com.travelzen.framework.core.exception.WebException;

public class FrontExceptionHandler {

	private static final Logger logger = LoggerFactory.getLogger(FrontExceptionHandler.class);
	
	public static ObjectResult<?> handleAjaxResponseException(Exception e) {
		if(e instanceof WebException) {
			WebException webException = (WebException)e;
			logger.warn(webException.getMessage(), webException);
			return ObjectResult.fail(webException.getMessage());
		} else {
			logger.error("系统异常", e);
			return ObjectResult.fail(ReturnCode.ERROR.getRetMsg());
		}
	}
	
}
