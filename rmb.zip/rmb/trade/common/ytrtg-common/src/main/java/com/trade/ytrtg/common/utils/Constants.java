package com.trade.ytrtg.common.utils;

/**
 * @author hu
 *
 */
public class Constants {
	
	// member
	
	public static final String SEQUENCE_NAME_USER_ID = "member_user_id";
	
	public static final String SEQUENCE_NAME_DEPARTMENT_ID = "member_department_id";

	public static final String SEQUENCE_NAME_POST_ID = "member_user_id";

	public static final String member_reg = "^[0-9|a-z|A-Z]{6,20}$";
	
	// information
	
	public static final String SEQUENCE_NAME_PUBLISH_CONFIG_ID = "information_public_config_id";
	
	public static final String SEQUENCE_NAME_NEWS_ID = "information_news_id";
	
	public static final String SEQUENCE_NAME_LECTURE_ID = "information_lecture_id";
	
	public static final String SEQUENCE_NAME_PAGE_VIEW_ID = "information_page_view_id";
	
	public static final String TRACE_ID = "rpid";

	public static final String TAGS = "tags";
	
	// 消息
	
	public static final String MESSAGE_NOTIFICATION_ID = "message_notification_id";
	
	public static final String SEQUENCE_NAME_PAGE_VIEW_DAY_ID = "information_page_view_day_id";
	
	public static final String SEQUENCE_NAME_LIKE_RECORD_ID = "like_record_id";
	
	// 图片
	
	public static final String CAROUSEL_PICTURES = "carousel_pictures";
	
	public static final String SCREEN_PICTURES = "screen_pictures";
	
	// auto complete
	public static final String AUTO_COMPLETE_PINYIN_NAME = "pinyin";
	
	// expert id
	public static final String EXPERT_ID = "expert_id";
	
	public static final String ORANIZATION_MEMBER_ID = "oranization_member_id";
	
	// bankgate
	public static final String BANKGATE_TRANS_ID = "bankgate_trans_id";
	public static final String BANKGATE_TRANS_GATESEQ = "bankgate_trans_gate_seq";

	public static final String ORDER_ID = "order_id";
	public static final String ORDER_GOODS_ID = "order_goods_id";
	
	public static final String USER_PURCHASE = "user_purchase_id";
	
	//url
	public static final String NEWS_OR_LECTURE_DETAIL_URL = "/information/detail/";
	public static final String RESEARCH_DETAIL_URL = "/research/detail?id=";
	
	//管理员岗位
	public static final String AdMIN_POST = "admin-post";
	public static final String AdMIN_DEPARTMENT = "admin-department";
}
