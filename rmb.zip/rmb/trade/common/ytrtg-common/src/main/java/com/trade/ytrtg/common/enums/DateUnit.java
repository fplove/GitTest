package com.trade.ytrtg.common.enums;

/**
 * @author hu
 *
 */
public enum DateUnit {

	year("年"),
	month("月"),
	day("日");
	
	private String desc;
	
	private DateUnit(String desc){
		this.desc = desc;
	}
	
	public String desc(){
		return this.desc;
	}
}
