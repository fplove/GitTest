package com.trade.ytrtg.common.member.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author hu
 *
 */
public class UserDTO implements Serializable {

	private static final long serialVersionUID = 4813542183108280472L;

	/**
     *用户ID
     */
    private String id;
    
	/**
     *用户名
     */
	private String username;

	/**
     *会员等级
     */
    private String vipLevel;
    
    /**
     *交易员等级
     */
    private String traderLevel;
    
    /**
     * 员工工号
     */
    private String employeeNo;
    
    /**
     *邮箱
     */
    private String email;
    
    /**
     *手机号码
     */
    private String phone;
    
    /**
     *注册时间
     */
    private Date registerTime;
    
    /**
     *状态
     */
    private String state;

    //页面需要
    /**
     *会员等级描述
     */
    private String vipLevelDesc;
    
    /**
     *交易员等级描述
     */
    private String traderLevelDesc;
    
    /**
     *高级会员过期时间
     */
    private Date vipExpirationTime;
    
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Date getRegisterTime() {
		return registerTime;
	}

	public void setRegisterTime(Date registerTime) {
		this.registerTime = registerTime;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getVipLevel() {
		return vipLevel;
	}

	public void setVipLevel(String vipLevel) {
		this.vipLevel = vipLevel;
	}

	public String getTraderLevel() {
		return traderLevel;
	}

	public void setTraderLevel(String traderLevel) {
		this.traderLevel = traderLevel;
	}

	public String getEmployeeNo() {
		return employeeNo;
	}

	public void setEmployeeNo(String employeeNo) {
		this.employeeNo = employeeNo;
	}

	public String getVipLevelDesc() {
		return vipLevelDesc;
	}

	public void setVipLevelDesc(String vipLevelDesc) {
		this.vipLevelDesc = vipLevelDesc;
	}

	public String getTraderLevelDesc() {
		return traderLevelDesc;
	}

	public void setTraderLevelDesc(String traderLevelDesc) {
		this.traderLevelDesc = traderLevelDesc;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getVipExpirationTime() {
		return vipExpirationTime;
	}

	public void setVipExpirationTime(Date vipExpirationTime) {
		this.vipExpirationTime = vipExpirationTime;
	}
}
