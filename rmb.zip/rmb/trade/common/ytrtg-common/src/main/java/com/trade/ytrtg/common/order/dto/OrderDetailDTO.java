package com.trade.ytrtg.common.order.dto;

import java.io.Serializable;
import java.util.List;

import com.trade.ytrtg.common.bankgate.enums.PayChannel;
import com.trade.ytrtg.common.order.enums.OrderState;

/**
 * 订单详情
 * 
 * @author XuMeng
 *
 */
public class OrderDetailDTO implements Serializable {

	private String orderId;
	private String goodsName;
	private String amount;
	private OrderState state;
	private PayChannel payChannel;
	private List<OrderGoodsDTO> goods;
	private String orderTime;
	private String userId;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getGoodsName() {
		return goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public OrderState getState() {
		return state;
	}

	public void setState(OrderState state) {
		this.state = state;
	}

	public PayChannel getPayChannel() {
		return payChannel;
	}

	public void setPayChannel(PayChannel payChannel) {
		this.payChannel = payChannel;
	}

	public List<OrderGoodsDTO> getGoods() {
		return goods;
	}

	public void setGoods(List<OrderGoodsDTO> goods) {
		this.goods = goods;
	}

	public String getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
}
