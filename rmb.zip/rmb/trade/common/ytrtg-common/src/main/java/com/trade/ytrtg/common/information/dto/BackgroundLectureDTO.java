package com.trade.ytrtg.common.information.dto;

public class BackgroundLectureDTO extends BasicBackgroundInformationDTO {

	private static final long serialVersionUID = 1L;

    /**
     *分类
     */
    private String classification;

    /**
     *内容摘要
     */
    private String summary;
    
    /**
     *适用人群
     */
    private String suitableCrowd;

    /**
     *时长（分）
     */
    private Integer duration;

    /**
     *是否收费
     */
    private Boolean chargeable;

    /**
     *价格（元）
     */
    private String fee;

    /**
     * 试看时长（分）
     */
    private Integer tryDuration;
    
    /**
     *是否有观看期限（true-无【永久】，false-有）
     */
    private Boolean unlimitable;
    
    /**
     *观看期限（天）
     */
    private Integer viewLimit;

    /**
     *讲义pdf地址
     */
    private String pdfMediaId;

    /**
     *讲义pdf转成的多个image地址
     */
    private String imageMediaIds;
    
    /**
     *封面图片地址
     */
    private String coverPhotoMediaId;

    /**
     *是否是草稿
     */
    private Boolean draft;

    /**
     *是否允许分享
     */
    private Boolean shared;
    
    /**
     * 培训名称
     */
    private String name;
    
    /**
     * 专家ID
     */
    private String specialist;
    
    /**
     *购买人数
     */
    private Integer purchaseNumber;
    
    /**
     *总浏览数
     */
    private Long pageViewTotal;
    
    /**
     * 作者名称
     */
    private String authorName;
    
    /**
     * 播放形式
     */
    private String playModes;
    
    /**
     *额外费用（会员专用）
     */
    private Long extraFee;

    /**
     *单篇费用（非会员专用）
     */
    private Long singleFee;
    
    /**
     *是否是会员文章
     */
    private Boolean memberAttributes;
    
    /**
     * 播放形式描述
     */
    private String playModesDesc;
    
    /**
     *视频地址
     */
    private String videoUrl;

	public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public Boolean getChargeable() {
		return chargeable;
	}

	public void setChargeable(Boolean chargeable) {
		this.chargeable = chargeable;
	}

	public String getFee() {
		return fee;
	}

	public void setFee(String fee) {
		this.fee = fee;
	}

	public Integer getViewLimit() {
		return viewLimit;
	}

	public void setViewLimit(Integer viewLimit) {
		this.viewLimit = viewLimit;
	}

	public String getCoverPhotoMediaId() {
		return coverPhotoMediaId;
	}

	public void setCoverPhotoMediaId(String coverPhotoMediaId) {
		this.coverPhotoMediaId = coverPhotoMediaId;
	}

	public Boolean getDraft() {
		return draft;
	}

	public void setDraft(Boolean draft) {
		this.draft = draft;
	}

	public Boolean getShared() {
		return shared;
	}

	public void setShared(Boolean shared) {
		this.shared = shared;
	}

	public Boolean getUnlimitable() {
		return unlimitable;
	}

	public void setUnlimitable(Boolean unlimitable) {
		this.unlimitable = unlimitable;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getTryDuration() {
		return tryDuration;
	}

	public void setTryDuration(Integer tryDuration) {
		this.tryDuration = tryDuration;
	}

	public String getSuitableCrowd() {
		return suitableCrowd;
	}

	public void setSuitableCrowd(String suitableCrowd) {
		this.suitableCrowd = suitableCrowd;
	}

	public String getSpecialist() {
		return specialist;
	}

	public void setSpecialist(String specialist) {
		this.specialist = specialist;
	}

	public String getPdfMediaId() {
		return pdfMediaId;
	}

	public void setPdfMediaId(String pdfMediaId) {
		this.pdfMediaId = pdfMediaId;
	}

	public String getImageMediaIds() {
		return imageMediaIds;
	}

	public void setImageMediaIds(String imageMediaIds) {
		this.imageMediaIds = imageMediaIds;
	}

	public Integer getPurchaseNumber() {
		return purchaseNumber;
	}

	public void setPurchaseNumber(Integer purchaseNumber) {
		this.purchaseNumber = purchaseNumber;
	}

	public Long getPageViewTotal() {
		return pageViewTotal;
	}

	public void setPageViewTotal(Long pageViewTotal) {
		this.pageViewTotal = pageViewTotal;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public String getPlayModes() {
		return playModes;
	}

	public void setPlayModes(String playModes) {
		this.playModes = playModes;
	}

	public Long getExtraFee() {
		return extraFee;
	}

	public void setExtraFee(Long extraFee) {
		this.extraFee = extraFee;
	}

	public Long getSingleFee() {
		return singleFee;
	}

	public void setSingleFee(Long singleFee) {
		this.singleFee = singleFee;
	}

	public Boolean getMemberAttributes() {
		return memberAttributes;
	}

	public void setMemberAttributes(Boolean memberAttributes) {
		this.memberAttributes = memberAttributes;
	}

	public String getPlayModesDesc() {
		return playModesDesc;
	}

	public void setPlayModesDesc(String playModesDesc) {
		this.playModesDesc = playModesDesc;
	}

	public String getVideoUrl() {
		return videoUrl;
	}

	public void setVideoUrl(String videoUrl) {
		this.videoUrl = videoUrl;
	}
	
}
