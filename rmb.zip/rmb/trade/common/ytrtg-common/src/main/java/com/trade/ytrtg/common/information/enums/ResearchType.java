package com.trade.ytrtg.common.information.enums;

public enum ResearchType {

	MEETING("会议研讨"),
	REPORT("研究报告");
	
	private String desc;
	
	private ResearchType(String desc) {
		this.setDesc(desc);
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String desc() {
		return desc;
	}
	
}
