package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * @author hu
 *
 */
public class ServiceResult implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4497002170940164531L;
	
	private String id;
	private String type;
	private boolean isPublished ;
	private boolean isDeleted ;
	private List<ServiceResult> resultList;

	public ServiceResult(){
	}
	
	public ServiceResult(String id, String type){
		this(id, type, Boolean.TRUE, Boolean.FALSE);
	}
	
	public ServiceResult(String id, String type, boolean isPublished, boolean isDeleted){
		this.id = id;
		this.type = type;
		this.isPublished = isPublished;
		this.isDeleted = isDeleted;
	}
	
	public void addServiceResult(String id, String type){
		this.addServiceResult(id, type, Boolean.TRUE, Boolean.FALSE);
	}
	
	public void addServiceResult(String id, String type, boolean isPublished, boolean isDeleted){
		if(null == resultList){
			resultList = Lists.newArrayList();
		}
		ServiceResult serviceResult = new ServiceResult(id, type, isPublished, isDeleted);
		resultList.add(serviceResult);
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public boolean isPublished() {
		return isPublished;
	}

	public void setPublished(boolean isPublished) {
		this.isPublished = isPublished;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
	
	public List<ServiceResult> getResultList() {
		return resultList;
	}

	public void setResultList(List<ServiceResult> resultList) {
		this.resultList = resultList;
	}

}
