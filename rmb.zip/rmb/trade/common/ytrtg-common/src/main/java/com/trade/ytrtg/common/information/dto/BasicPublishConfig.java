package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;

/**
 * @author hu
 *
 */
public class BasicPublishConfig implements Serializable{

	private static final long serialVersionUID = 7710467052650686058L;

	private String[] tags;
	
	private String[] type;

	public String[] getTags() {
		return tags;
	}

	public void setTags(String[] tags) {
		this.tags = tags;
	}

	public String[] getType() {
		return type;
	}

	public void setType(String[] type) {
		this.type = type;
	}

}
