package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;
import java.util.List;

public class BasicBackgroundInformationSearchCriteria implements Serializable {

	private static final long serialVersionUID = 1L;

    // 页码，从1开始
    private int page = 1;
    
    // 每页的行数
    private int pageSize;
    
    //信息ID
    private String informationId;
    
    // 频道
    private String subType;
    
    // 发布者ID（工号）
    private String publisherId;
    
    // 发布者姓名
    private String publishName;
    
    // 标题关键字
    private String titleKeywords;
    
	// 信息创建开始时间
    private String createStartTime;
    
    // 信息创建结束时间
    private String createEndTime;

    // 标题关键字分词后列表--不用于前端，用于后台
    private List<String> ikTitleKeywords;
    
    //是否只查草稿
    private Boolean draft; 

    public String getTitleKeywords() {
    	return titleKeywords;
    }
    
    public void setTitleKeywords(String titleKeywords) {
    	this.titleKeywords = titleKeywords;
    }
    
	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getPublisherId() {
		return publisherId;
	}

	public void setPublisherId(String publisherId) {
		this.publisherId = publisherId;
	}

	public String getPublishName() {
		return publishName;
	}

	public void setPublishName(String publishName) {
		this.publishName = publishName;
	}

	public String getCreateStartTime() {
		return createStartTime;
	}

	public void setCreateStartTime(String createStartTime) {
		this.createStartTime = createStartTime;
	}

	public String getCreateEndTime() {
		return createEndTime;
	}

	public void setCreateEndTime(String createEndTime) {
		this.createEndTime = createEndTime;
	}

	public List<String> getIkTitleKeywords() {
		return ikTitleKeywords;
	}

	public void setIkTitleKeywords(List<String> ikTitleKeywords) {
		this.ikTitleKeywords = ikTitleKeywords;
	}

	public String getInformationId() {
		return informationId;
	}

	public void setInformationId(String informationId) {
		this.informationId = informationId;
	}

	public Boolean getDraft() {
		return draft;
	}

	public void setDraft(Boolean draft) {
		this.draft = draft;
	}
    
}
