package com.trade.ytrtg.common.information.dto;

public class NewsPublishConfig extends BasicPublishConfig {

	private static final long serialVersionUID = 1L;

	
}
