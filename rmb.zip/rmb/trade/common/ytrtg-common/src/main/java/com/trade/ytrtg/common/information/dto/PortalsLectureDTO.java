package com.trade.ytrtg.common.information.dto;

import com.trade.ytrtg.common.fee.dto.ChargeInfo;

public class PortalsLectureDTO extends BasicPortalsInformationDTO {

	private static final long serialVersionUID = 1L;

	/**
	 * 子频道描述
	 */
	private String subTypeDesc;
	
	/**
	 * 播放形式
	 */
	private String playModes;
	
	/**
	 * 播放形式描述
	 */
	private String playModesDesc;
	
	/**
	 * 名称
	 */
	private String name;
	
	/**
	 * 分类
	 */
	private String classification;
	
	/**
     *适用人群
     */
    private String suitableCrowd;
    
    /**
     *时长（分）
     */
    private Integer duration;
    
    /**
     *是否收费
     */
    private Boolean chargeable;

    /**
     *价格（元）
     */
    private String fee;
    
    /**
     *试看时长（分）
     */
    private Integer tryDuration;

    /**
     *是否有观看期限（true-无【永久】，false-有）
     */
    private Boolean unlimitable;

    /**
     *观看期限（天）
     */
    private Integer viewLimit;
    
    /**
     *购买人数
     */
    private Integer purchaseNumber;
    
    /**
     *总浏览数
     */
    private Long pageViewTotal;
    
    /**
     *讲义pdf地址
     */
    private String pdfMediaId;

    /**
     *讲义pdf转成的多个image地址
     */
    private String imageMediaIds;
    
    /**
     *封面图片地址
     */
    private String coverPhotoMediaId;
    
    /**
     * 专家ID
     */
    private String specialist;
    
    /**
	 * 专家名誉
	 */
	private String reputationName;
	
	/**
	 * 专家职位
	 */
	private String positionName;
	
	/**
	 * 照片Id
	 */
	private String imageId;
	
	//专家简介
	private String expertIntroduction;

	private Long extraFee;
	
	private Long singleFee;
	
	private Boolean memberAttributes;

	private ChargeInfo chargeInfo;
	
	private String videoUrl;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

	public String getSuitableCrowd() {
		return suitableCrowd;
	}

	public void setSuitableCrowd(String suitableCrowd) {
		this.suitableCrowd = suitableCrowd;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public Boolean getChargeable() {
		return chargeable;
	}

	public void setChargeable(Boolean chargeable) {
		this.chargeable = chargeable;
	}

	public Integer getTryDuration() {
		return tryDuration;
	}

	public void setTryDuration(Integer tryDuration) {
		this.tryDuration = tryDuration;
	}

	public Boolean getUnlimitable() {
		return unlimitable;
	}

	public void setUnlimitable(Boolean unlimitable) {
		this.unlimitable = unlimitable;
	}

	public Integer getViewLimit() {
		return viewLimit;
	}

	public void setViewLimit(Integer viewLimit) {
		this.viewLimit = viewLimit;
	}

	public Integer getPurchaseNumber() {
		return purchaseNumber;
	}

	public void setPurchaseNumber(Integer purchaseNumber) {
		this.purchaseNumber = purchaseNumber;
	}

	public String getCoverPhotoMediaId() {
		return coverPhotoMediaId;
	}

	public void setCoverPhotoMediaId(String coverPhotoMediaId) {
		this.coverPhotoMediaId = coverPhotoMediaId;
	}

	public String getSubTypeDesc() {
		return subTypeDesc;
	}

	public void setSubTypeDesc(String subTypeDesc) {
		this.subTypeDesc = subTypeDesc;
	}

	public String getFee() {
		return fee;
	}

	public void setFee(String fee) {
		this.fee = fee;
	}

	public String getSpecialist() {
		return specialist;
	}

	public void setSpecialist(String specialist) {
		this.specialist = specialist;
	}

	public Long getPageViewTotal() {
		return pageViewTotal;
	}

	public void setPageViewTotal(Long pageViewTotal) {
		this.pageViewTotal = pageViewTotal;
	}

	public String getPdfMediaId() {
		return pdfMediaId;
	}

	public void setPdfMediaId(String pdfMediaId) {
		this.pdfMediaId = pdfMediaId;
	}

	public String getImageMediaIds() {
		return imageMediaIds;
	}

	public void setImageMediaIds(String imageMediaIds) {
		this.imageMediaIds = imageMediaIds;
	}

	public String getReputationName() {
		return reputationName;
	}

	public void setReputationName(String reputationName) {
		this.reputationName = reputationName;
	}

	public String getPositionName() {
		return positionName;
	}

	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}

	public String getImageId() {
		return imageId;
	}

	public void setImageId(String imageId) {
		this.imageId = imageId;
	}

	public String getExpertIntroduction() {
		return expertIntroduction;
	}

	public void setExpertIntroduction(String expertIntroduction) {
		this.expertIntroduction = expertIntroduction;
	}

	public String getPlayModesDesc() {
		return playModesDesc;
	}

	public void setPlayModesDesc(String playModesDesc) {
		this.playModesDesc = playModesDesc;
	}

	public String getPlayModes() {
		return playModes;
	}

	public void setPlayModes(String playModes) {
		this.playModes = playModes;
	}

	public Long getExtraFee() {
		return extraFee;
	}

	public void setExtraFee(Long extraFee) {
		this.extraFee = extraFee;
	}

	public Long getSingleFee() {
		return singleFee;
	}

	public void setSingleFee(Long singleFee) {
		this.singleFee = singleFee;
	}

	public Boolean getMemberAttributes() {
		return memberAttributes;
	}

	public void setMemberAttributes(Boolean memberAttributes) {
		this.memberAttributes = memberAttributes;
	}

	public ChargeInfo getChargeInfo() {
		return chargeInfo;
	}

	public void setChargeInfo(ChargeInfo chargeInfo) {
		this.chargeInfo = chargeInfo;
	}

	public String getVideoUrl() {
		return videoUrl;
	}

	public void setVideoUrl(String videoUrl) {
		this.videoUrl = videoUrl;
	}
	
}
