package com.trade.ytrtg.common.order.dto;

import java.io.Serializable;

import com.trade.ytrtg.common.order.enums.OrderGoodsType;

/**
 * 订单商品
 * 
 * @author XuMeng
 *
 */
public class OrderGoodsDTO implements Serializable {

	private String goodsName;
	private String amount;
	private OrderGoodsType goodsType;
	private String goodsUrl;
	private String validityStartDate;
	private String validityEndDate;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String getGoodsName() {
		return goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public OrderGoodsType getGoodsType() {
		return goodsType;
	}

	public void setGoodsType(OrderGoodsType goodsType) {
		this.goodsType = goodsType;
	}

	public String getGoodsUrl() {
		return goodsUrl;
	}

	public void setGoodsUrl(String goodsUrl) {
		this.goodsUrl = goodsUrl;
	}

	public String getValidityStartDate() {
		return validityStartDate;
	}

	public void setValidityStartDate(String validityStartDate) {
		this.validityStartDate = validityStartDate;
	}

	public String getValidityEndDate() {
		return validityEndDate;
	}

	public void setValidityEndDate(String validityEndDate) {
		this.validityEndDate = validityEndDate;
	}

}
