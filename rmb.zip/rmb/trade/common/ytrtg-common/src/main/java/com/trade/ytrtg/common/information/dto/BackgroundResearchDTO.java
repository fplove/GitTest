package com.trade.ytrtg.common.information.dto;

public class BackgroundResearchDTO extends BasicBackgroundInformationDTO {

	private static final long serialVersionUID = 1L;

	/**
     *报告分类
     */
    private String classification;
    
    /**
     *文章摘要
     */
    private String summary;

    private String authorName;

    /**
     *是否是草稿
     */
    private Boolean draft;

    /**
     *是否允许分享
     */
    private Boolean shared;

    /**
     *文章内容
     */
    private String content;
    
    /**
     *议题
     */
    private String issue;

    /**
     *是否放置首页
     */
    private Boolean onHome;
    
    /**
     *会议时间
     */
    private String meetingTime;

    /**
     *会议地点
     */
    private String meetingAddress;

    /**
     *报告pdf地址
     */
    private String pdfMediaId;

    /**
     *报告pdf转成的多个image地址
     */
    private String imageMediaIds;
    
    /**
     *额外费用（会员专用）
     */
    private Long extraFee;

    /**
     *单篇费用（非会员专用）
     */
    private Long singleFee;
    
    /**
     *是否是会员文章
     */
    private Boolean memberAttributes;
    
    private String updateTime;//更新时间
    
	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public Boolean getDraft() {
		return draft;
	}

	public void setDraft(Boolean draft) {
		this.draft = draft;
	}

	public Boolean getShared() {
		return shared;
	}

	public void setShared(Boolean shared) {
		this.shared = shared;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getIssue() {
		return issue;
	}

	public void setIssue(String issue) {
		this.issue = issue;
	}

	public Boolean getOnHome() {
		return onHome;
	}

	public void setOnHome(Boolean onHome) {
		this.onHome = onHome;
	}

	public String getMeetingAddress() {
		return meetingAddress;
	}

	public void setMeetingAddress(String meetingAddress) {
		this.meetingAddress = meetingAddress;
	}

	public String getMeetingTime() {
		return meetingTime;
	}

	public void setMeetingTime(String meetingTime) {
		this.meetingTime = meetingTime;
	}

	public String getPdfMediaId() {
		return pdfMediaId;
	}

	public void setPdfMediaId(String pdfMediaId) {
		this.pdfMediaId = pdfMediaId;
	}

	public String getImageMediaIds() {
		return imageMediaIds;
	}

	public void setImageMediaIds(String imageMediaIds) {
		this.imageMediaIds = imageMediaIds;
	}

	public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

	public Long getExtraFee() {
		return extraFee;
	}

	public void setExtraFee(Long extraFee) {
		this.extraFee = extraFee;
	}

	public Long getSingleFee() {
		return singleFee;
	}

	public void setSingleFee(Long singleFee) {
		this.singleFee = singleFee;
	}

	public Boolean getMemberAttributes() {
		return memberAttributes;
	}

	public void setMemberAttributes(Boolean memberAttributes) {
		this.memberAttributes = memberAttributes;
	}
	
	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

}
