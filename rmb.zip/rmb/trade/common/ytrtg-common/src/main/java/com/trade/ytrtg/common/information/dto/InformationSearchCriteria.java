package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class InformationSearchCriteria implements Serializable {

	private static final long serialVersionUID = 1L;

    // 页码，从1开始
    private int page = 1;
    
    // 每页的行数
    private int pageSize;
    
    //信息ID
    private String informationId;
    
    // 子频道
    private String subType;
    
    // 发布者ID（工号）
    private String publisherId;
    
    // 发布者姓名
    private String publishName;
    
	// 信息创建开始时间
    private Date createStartTime;
    
    // 信息创建结束时间
    private Date createEndTime;

    // 标题关键字分词后列表--不用于前端，用于后台
    private List<String> ikTitleKeywords;
    
    //是否只查草稿
    private Boolean draft;

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getPublisherId() {
		return publisherId;
	}

	public void setPublisherId(String publisherId) {
		this.publisherId = publisherId;
	}

	public String getPublishName() {
		return publishName;
	}

	public void setPublishName(String publishName) {
		this.publishName = publishName;
	}

	public List<String> getIkTitleKeywords() {
		return ikTitleKeywords;
	}

	public void setIkTitleKeywords(List<String> ikTitleKeywords) {
		this.ikTitleKeywords = ikTitleKeywords;
	}

	public Date getCreateStartTime() {
		return createStartTime;
	}

	public void setCreateStartTime(Date createStartTime) {
		this.createStartTime = createStartTime;
	}

	public Date getCreateEndTime() {
		return createEndTime;
	}

	public void setCreateEndTime(Date createEndTime) {
		this.createEndTime = createEndTime;
	}

	public String getInformationId() {
		return informationId;
	}

	public void setInformationId(String informationId) {
		this.informationId = informationId;
	}

	public Boolean getDraft() {
		return draft;
	}

	public void setDraft(Boolean draft) {
		this.draft = draft;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}
}
