package com.trade.ytrtg.common.information.enums;

/**
 * @author hu
 *
 */
public enum ChannelType {

	NEWS("交易研究","交易研究"),
	REALTIMEINFORMATION("交易备忘", "交易备忘"),
	LECTURE("交易培训", "交易培训"),
	RESEARCH("人民币研究院","人民币研究院");
	
	private String desc;
	private String portalsDesc;
	private ChannelType(String desc,String portalsDesc){
		this.setDesc(desc);
		this.setPortalsDesc(portalsDesc);
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String desc() {
		return desc;
	}
	
	public String portalsDesc() {
		return portalsDesc;
	}

	public String getPortalsDesc() {
		return portalsDesc;
	}

	public void setPortalsDesc(String portalsDesc) {
		this.portalsDesc = portalsDesc;
	}
	
}
