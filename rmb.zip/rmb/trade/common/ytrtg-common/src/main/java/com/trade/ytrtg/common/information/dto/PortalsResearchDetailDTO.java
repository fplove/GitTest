package com.trade.ytrtg.common.information.dto;

public class PortalsResearchDetailDTO extends BasicPortalsInformationDTO {
	
	private static final long serialVersionUID = 1L;

	private Long pageViewTotal;
	
	private boolean shared;
	
	private String content;
	
	private String subTypeDesc;
	
	/**
     *议题
     */
    private String issue;

    /**
     *是否放置首页
     */
    private Boolean onHome;
    
    /**
     *会议时间
     */
    private String meetingTime;

    /**
     *会议地点
     */
    private String meetingAddress;
    
    /**
     *报告pdf地址
     */
    private String pdfMediaId;

    /**
     *报告pdf转成的多个image地址
     */
    private String imageMediaIds;
    
    /**
     *额外费用（会员专用）
     */
    private Long extraFee;

    /**
     *单篇费用（非会员专用）
     */
    private Long singleFee;

    /**
     *是否是会员文章
     */
    private Boolean memberAttributes;

	public Long getPageViewTotal() {
		return pageViewTotal;
	}

	public void setPageViewTotal(Long pageViewTotal) {
		this.pageViewTotal = pageViewTotal;
	}

	public boolean isShared() {
		return shared;
	}

	public void setShared(boolean shared) {
		this.shared = shared;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getSubTypeDesc() {
		return subTypeDesc;
	}

	public void setSubTypeDesc(String subTypeDesc) {
		this.subTypeDesc = subTypeDesc;
	}

	public String getIssue() {
		return issue;
	}

	public void setIssue(String issue) {
		this.issue = issue;
	}

	public Boolean getOnHome() {
		return onHome;
	}

	public void setOnHome(Boolean onHome) {
		this.onHome = onHome;
	}

	public String getMeetingAddress() {
		return meetingAddress;
	}

	public void setMeetingAddress(String meetingAddress) {
		this.meetingAddress = meetingAddress;
	}

	public String getMeetingTime() {
		return meetingTime;
	}

	public void setMeetingTime(String meetingTime) {
		this.meetingTime = meetingTime;
	}

	public String getPdfMediaId() {
		return pdfMediaId;
	}

	public void setPdfMediaId(String pdfMediaId) {
		this.pdfMediaId = pdfMediaId;
	}

	public String getImageMediaIds() {
		return imageMediaIds;
	}

	public void setImageMediaIds(String imageMediaIds) {
		this.imageMediaIds = imageMediaIds;
	}

	public Long getExtraFee() {
		return extraFee;
	}

	public void setExtraFee(Long extraFee) {
		this.extraFee = extraFee;
	}

	public Long getSingleFee() {
		return singleFee;
	}

	public void setSingleFee(Long singleFee) {
		this.singleFee = singleFee;
	}

	public Boolean getMemberAttributes() {
		return memberAttributes;
	}

	public void setMemberAttributes(Boolean memberAttributes) {
		this.memberAttributes = memberAttributes;
	}

}
