package com.trade.ytrtg.common.information.enums;

public enum RealtimeFontType {

	BOLD_RED("标红+加粗"),
	BOLD("加粗"),
	RED("标红");
	
	private String desc;
	
	private RealtimeFontType(String desc) {
		this.setDesc(desc);
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}
