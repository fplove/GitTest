package com.trade.ytrtg.common.information.dto;

/**
 * @author hu
 *
 */
public class LecturePublishConfig extends BasicPublishConfig{

	private static final long serialVersionUID = 1L;
	
    private Integer tryDuration;
    
    private Integer viewLimit;

	public Integer getTryDuration() {
		return tryDuration;
	}

	public void setTryDuration(Integer tryDuration) {
		this.tryDuration = tryDuration;
	}

	public Integer getViewLimit() {
		return viewLimit;
	}

	public void setViewLimit(Integer viewLimit) {
		this.viewLimit = viewLimit;
	}

}
