package com.trade.ytrtg.common.information.dto;

public class PortalsNewsDetailDTO extends PortalsNewsSummaryDTO {
	
	private static final long serialVersionUID = 1L;

	private Long pageViewTotal;
	
	private Boolean memberAttributes;
	
	private Boolean shared;
	
	private String content;
	
	/**
     *额外费用（会员专用）
     */
    private Long extraFee;

    /**
     *单篇费用（非会员专用）
     */
    private Long singleFee;

	public Long getPageViewTotal() {
		return pageViewTotal;
	}

	public void setPageViewTotal(Long pageViewTotal) {
		this.pageViewTotal = pageViewTotal;
	}

	public Boolean getMemberAttributes() {
		return memberAttributes;
	}

	public void setMemberAttributes(Boolean memberAttributes) {
		this.memberAttributes = memberAttributes;
	}

	public Boolean getShared() {
		return shared;
	}

	public void setShared(Boolean shared) {
		this.shared = shared;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Long getExtraFee() {
		return extraFee;
	}

	public void setExtraFee(Long extraFee) {
		this.extraFee = extraFee;
	}

	public Long getSingleFee() {
		return singleFee;
	}

	public void setSingleFee(Long singleFee) {
		this.singleFee = singleFee;
	}
	
}
