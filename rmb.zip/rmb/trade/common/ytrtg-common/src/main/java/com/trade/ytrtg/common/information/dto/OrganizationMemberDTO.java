package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;

public class OrganizationMemberDTO implements Serializable {

	private static final long serialVersionUID = -6357121969443923146L;

	/**
     *主键
     */
    private String id;

    /**
     *机构名称
     */
    private String name;

    /**
     *照片Id
     */
    private String imageId;

    /**
     *描述
     */
    private String introduction;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImageId() {
		return imageId;
	}

	public void setImageId(String imageId) {
		this.imageId = imageId;
	}

	public String getIntroduction() {
		return introduction;
	}

	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}
	
}
