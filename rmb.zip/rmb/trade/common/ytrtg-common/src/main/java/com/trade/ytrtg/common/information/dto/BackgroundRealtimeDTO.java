package com.trade.ytrtg.common.information.dto;

public class BackgroundRealtimeDTO extends BasicBackgroundInformationDTO {

	private static final long serialVersionUID = 1L;

    /**
     *信息类型
     */
    private String informationType;
    
    /**
     *信息标签（多个标签用“,”分隔）
     */
    private String informationTags;
    
    /**
     *重要程度
     */
    private String importance;

    /**
     *重要时门户展示字体格式
     */
    private String importantFont;
    
    /**
     *文章内容
     */
    private String content;
    
    /**
     *是否放置首页
     */
    private Boolean onHome;
    
    /**
     *是否是草稿
     */
    private Boolean draft;
    
    /**
     *重要时门户展示字体格式描述
     */
    private String importantFontDesc;
    
    //更新日期，格式 2016/02/20，预览需要
  	private String updateDateStr;
  	
  	//更新时间，格式 09:31，预览需要
  	private String updateTimeStr;

  	//更新时间，格式 2016年02月20日 12:59，预览需要
  	private String updateTime;
  	
	public String getImportance() {
		return importance;
	}

	public void setImportance(String importance) {
		this.importance = importance;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Boolean getOnHome() {
		return onHome;
	}

	public void setOnHome(Boolean onHome) {
		this.onHome = onHome;
	}

	public Boolean getDraft() {
		return draft;
	}

	public void setDraft(Boolean draft) {
		this.draft = draft;
	}

	public String getImportantFont() {
		return importantFont;
	}

	public void setImportantFont(String importantFont) {
		this.importantFont = importantFont;
	}

	public String getImportantFontDesc() {
		return importantFontDesc;
	}

	public void setImportantFontDesc(String importantFontDesc) {
		this.importantFontDesc = importantFontDesc;
	}

	public String getInformationType() {
		return informationType;
	}

	public void setInformationType(String informationType) {
		this.informationType = informationType;
	}

	public String getInformationTags() {
		return informationTags;
	}

	public void setInformationTags(String informationTags) {
		this.informationTags = informationTags;
	}

	public String getUpdateDateStr() {
		return updateDateStr;
	}

	public void setUpdateDateStr(String updateDateStr) {
		this.updateDateStr = updateDateStr;
	}

	public String getUpdateTimeStr() {
		return updateTimeStr;
	}

	public void setUpdateTimeStr(String updateTimeStr) {
		this.updateTimeStr = updateTimeStr;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
    
}
