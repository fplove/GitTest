package com.trade.ytrtg.common.information.dto;

import com.trade.ytrtg.common.dto.PaginationCriteria;

public class RecentSummaryNewsSearchCriteria extends PaginationCriteria {

	private static final long serialVersionUID = 1L;

	private String tagRegular;
	
	private int offset;

	public String getTagRegular() {
		return tagRegular;
	}

	public void setTagRegular(String tagRegular) {
		this.tagRegular = tagRegular;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

}
