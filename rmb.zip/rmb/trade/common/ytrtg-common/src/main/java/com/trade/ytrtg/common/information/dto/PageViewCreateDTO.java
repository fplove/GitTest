package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;

import com.trade.ytrtg.common.information.enums.ChannelType;

/**
 * @author hu
 *
 */
public class PageViewCreateDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3245196808158483686L;

	private String informationId;
	
	private ChannelType informationType;
	
	private String sessionId;
	
	private String userId;

	public String getInformationId() {
		return informationId;
	}

	public void setInformationId(String informationId) {
		this.informationId = informationId;
	}

	public ChannelType getInformationType() {
		return informationType;
	}

	public void setInformationType(ChannelType informationType) {
		this.informationType = informationType;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
}
