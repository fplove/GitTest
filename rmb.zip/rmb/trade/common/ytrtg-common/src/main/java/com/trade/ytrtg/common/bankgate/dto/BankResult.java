package com.trade.ytrtg.common.bankgate.dto;

import java.io.Serializable;

import com.trade.ytrtg.common.bankgate.enums.BankGateTranState;

public class BankResult implements Serializable{

	private static final long serialVersionUID = 429336326047473690L;

	//支付金额
	private long amount;
	// 网关产生的流水
	private String gateSeq;
	//银行交易状态
	private BankGateTranState state;
	//银行产生的流水
	private String bankSeq;
	//银行对账日期, 格式:yyyy-MM-dd
	private String bankCheckDate;
	
	public BankGateTranState getState() {
		return state;
	}
	public void setState(BankGateTranState state) {
		this.state = state;
	}
	public String getBankSeq() {
		return bankSeq;
	}
	public void setBankSeq(String bankSeq) {
		this.bankSeq = bankSeq;
	}
	public String getBankCheckDate() {
		return bankCheckDate;
	}
	public void setBankCheckDate(String bankCheckDate) {
		this.bankCheckDate = bankCheckDate;
	}
	public String getGateSeq() {
		return gateSeq;
	}
	public void setGateSeq(String gateSeq) {
		this.gateSeq = gateSeq;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	
}
