package com.trade.ytrtg.common.bankgate.dto;

import java.io.Serializable;

public class ReqBankParam implements Serializable{
	
	private static final long serialVersionUID = -46594535448257329L;
	
	// 参数名
	private String paramName;
	// 参数值
	private String paramValue;
	
	public static ReqBankParam of(String paramName , String paramValue){
		ReqBankParam param = new ReqBankParam();
		param.setParamName(paramName);
		param.setParamValue(paramValue);
		return param;
	}
	
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public String getParamValue() {
		return paramValue;
	}
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

}
