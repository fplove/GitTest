package com.trade.ytrtg.common.enums;

public enum AjaxResponseStatus {
	//请求成功
    SUCCESS,
    //请求失败
    FAILED,
    //请求中断，警告
    WARNING;
}
