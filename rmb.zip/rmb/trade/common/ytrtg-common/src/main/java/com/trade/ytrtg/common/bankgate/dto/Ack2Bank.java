package com.trade.ytrtg.common.bankgate.dto;

import java.io.Serializable;

public class Ack2Bank implements Serializable{
	
	private static final long serialVersionUID = -4578818524593530498L;

	// 成功接收通知后给银行的ACK消息
	private String ack;

	public String getAck() {
		return ack;
	}

	public void setAck(String ack) {
		this.ack = ack;
	}
	
	
}
