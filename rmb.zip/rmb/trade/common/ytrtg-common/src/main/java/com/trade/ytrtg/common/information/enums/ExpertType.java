package com.trade.ytrtg.common.information.enums;

/**  
 *  
 * @author lewis.yang  
 */
public enum ExpertType {

	lecturer("讲师"),
	expert("专家");
	
	private String desc;
	
	private ExpertType(String desc) {
		this.setDesc(desc);
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
}
