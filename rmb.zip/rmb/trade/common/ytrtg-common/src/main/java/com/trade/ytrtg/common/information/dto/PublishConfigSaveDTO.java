package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;

public class PublishConfigSaveDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String channelType;
	
	private String data;

	public String getChannelType() {
		return channelType;
	}

	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
	
}
