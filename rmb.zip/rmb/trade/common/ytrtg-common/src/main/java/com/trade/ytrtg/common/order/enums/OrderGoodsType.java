package com.trade.ytrtg.common.order.enums;

/**
 * 订单商品类型
 */
public enum OrderGoodsType {

	vip("会员费"),
	extra_charge("附加费"),
	article("单篇文章");
	
	private String desc;
	private OrderGoodsType(String desc){
		this.desc = desc;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String desc() {
		return desc;
	}
	
}
