package com.trade.ytrtg.common.member.dto;

import java.io.Serializable;
/**
 * 
 * @author lewis.yang
 */
public class UserBasicInfoDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8003440532948714150L;
	
    /**
     * 主键
     */
    private String id;
	
	/**
	 * 用户名
	 */
	private String username;

    /**
     * 真实姓名
     */
    private String realName;

    /**
     * 性别
     */
    private String gender;
	
	/**
	 * 所属行业
	 */
	private String industry;
	
	/**
	 * 所属公司
	 */
	private String companyName;
	
	/**
	 * 所属部门
	 */
	private String companyDepartment;
	
	/**
	 * 职位
	 */
	private String companyJob;
	
	/**
	 * 月收入
	 */
	private String companyMonthlySalary;
	
    /**
     *邮箱
     */
    private String email;

    /**
     *手机号码
     */
    private String phone;
	
	/**
	 * 关注标签
	 */
	private String interestTags;
	
	/**
	 * 头像Id
	 */
	private String photoImageId;
	
	 /**
     *婚姻状况(已婚,未婚,保密)
     */
    private String maritalStatus;
    
    /**
     *生日
     */
    private String birthday;

    /**
     *教育状况(在职、学生、自由职业者、无业)
     */
    private String educationalStatus;

    /**
     *教育程度(大专以下、大专、本科、硕士、硕士以上)
     */
    private String educationalDegree;

    /**
     *毕业学校
     */
    private String graduateSchool;

    /**
     *身份证号码
     */
    private String identityCardNo;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyDepartment() {
		return companyDepartment;
	}

	public void setCompanyDepartment(String companyDepartment) {
		this.companyDepartment = companyDepartment;
	}

	public String getCompanyJob() {
		return companyJob;
	}

	public void setCompanyJob(String companyJob) {
		this.companyJob = companyJob;
	}

	public String getCompanyMonthlySalary() {
		return companyMonthlySalary;
	}

	public void setCompanyMonthlySalary(String companyMonthlySalary) {
		this.companyMonthlySalary = companyMonthlySalary;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getInterestTags() {
		return interestTags;
	}

	public void setInterestTags(String interestTags) {
		this.interestTags = interestTags;
	}

	public String getPhotoImageId() {
		return photoImageId;
	}

	public void setPhotoImageId(String photoImageId) {
		this.photoImageId = photoImageId;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getEducationalStatus() {
		return educationalStatus;
	}

	public void setEducationalStatus(String educationalStatus) {
		this.educationalStatus = educationalStatus;
	}

	public String getEducationalDegree() {
		return educationalDegree;
	}

	public void setEducationalDegree(String educationalDegree) {
		this.educationalDegree = educationalDegree;
	}

	public String getGraduateSchool() {
		return graduateSchool;
	}

	public void setGraduateSchool(String graduateSchool) {
		this.graduateSchool = graduateSchool;
	}

	public String getIdentityCardNo() {
		return identityCardNo;
	}

	public void setIdentityCardNo(String identityCardNo) {
		this.identityCardNo = identityCardNo;
	}
	
}
