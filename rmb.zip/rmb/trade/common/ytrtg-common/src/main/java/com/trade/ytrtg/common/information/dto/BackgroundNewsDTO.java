package com.trade.ytrtg.common.information.dto;

public class BackgroundNewsDTO extends BasicBackgroundInformationDTO {

	private static final long serialVersionUID = 1L;

    /**
     *文章摘要
     */
    private String summary;

    /**
     *文章标签（多个标签用“,”分隔）
     */
    private String tags;
    
    private String authorName;

    /**
     *是否是会员文章
     */
    private Boolean memberAttributes;

    /**
     *是否是草稿
     */
    private Boolean draft;

    /**
     *是否允许分享
     */
    private Boolean shared;

    /**
     *文章内容
     */
    private String content;

    /**
     *图片地址
     */
    private String pictureMediaId;
    
    /**
     *额外费用（会员专用）
     */
    private Long extraFee;

    /**
     *单篇费用（非会员专用）
     */
    private Long singleFee;

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getTags() {
		return tags;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public Boolean getMemberAttributes() {
		return memberAttributes;
	}

	public void setMemberAttributes(Boolean memberAttributes) {
		this.memberAttributes = memberAttributes;
	}

	public Boolean getDraft() {
		return draft;
	}

	public void setDraft(Boolean draft) {
		this.draft = draft;
	}

	public Boolean getShared() {
		return shared;
	}

	public void setShared(Boolean shared) {
		this.shared = shared;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getPictureMediaId() {
		return pictureMediaId;
	}

	public void setPictureMediaId(String pictureMediaId) {
		this.pictureMediaId = pictureMediaId;
	}

	public Long getExtraFee() {
		return extraFee;
	}

	public void setExtraFee(Long extraFee) {
		this.extraFee = extraFee;
	}

	public Long getSingleFee() {
		return singleFee;
	}

	public void setSingleFee(Long singleFee) {
		this.singleFee = singleFee;
	}

}
