package com.trade.ytrtg.common.member.dto;

import java.io.Serializable;

/**
 * @author hu
 *
 */
public class EmployeeDTO implements Serializable {

	 /**
	 * 
	 */
	private static final long serialVersionUID = -3113848271696110614L;

	/**
     *用户ID
     */
    private String id;
    
    /**
     *用户名
     */
    private String username;
    
    /**
     *用户姓名
     */
    private String realName;
    
    /**
     * 员工工号
     */
    private String employeeNo;

    /**
     *邮箱
     */
    private String email;
    
    /**
     *所属部门
     */
    private String department;

    /**
     *岗位名称
     */
    private String postName;
    
    /**
     *状态
     */
    private String state;
    
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public String getEmployeeNo() {
		return employeeNo;
	}
	public void setEmployeeNo(String employeeNo) {
		this.employeeNo = employeeNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getPostName() {
		return postName;
	}
	public void setPostName(String postName) {
		this.postName = postName;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
}
