package com.trade.ytrtg.common.bankgate.dto;

import java.io.Serializable;
import java.util.Map;

import com.trade.ytrtg.common.bankgate.enums.PayChannel;

public class ProcessBankPayResultNotificationRequest implements Serializable{

	private static final long serialVersionUID = -99392695933087146L;
	
	// 支付渠道标识
	private PayChannel payChannelId;
	//结果参数
	private Map<String, String> resultParams;
	
	public PayChannel getPayChannelId() {
		return payChannelId;
	}
	public void setPayChannelId(PayChannel payChannelId) {
		this.payChannelId = payChannelId;
	}
	public Map<String, String> getResultParams() {
		return resultParams;
	}
	public void setResultParams(Map<String, String> resultParams) {
		this.resultParams = resultParams;
	}
	
}
