package com.trade.ytrtg.common.member.enums;

/**
 * @author hu
 *
 */
public enum UserState {

	ACTIVATE("已激活"),
	NONACTIVATE("未激活");
	private String desc;
	
	private UserState(String desc){
		this.desc = desc;
	}
	
	public String desc(){
		return desc;
	}
}
