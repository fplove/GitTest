package com.trade.ytrtg.common.information.dto;

public class NewsListDTO extends BasicInformationListDTO {

	private static final long serialVersionUID = 1L;

	private String pictureMediaId;

	public String getPictureMediaId() {
		return pictureMediaId;
	}

	public void setPictureMediaId(String pictureMediaId) {
		this.pictureMediaId = pictureMediaId;
	}
	
}
