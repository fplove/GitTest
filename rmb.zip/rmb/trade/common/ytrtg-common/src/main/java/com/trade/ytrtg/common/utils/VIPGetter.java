package com.trade.ytrtg.common.utils;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.travelzen.framework.config.tops.TopsConfClient;

public class VIPGetter {

	private static Logger logger = LoggerFactory.getLogger(VIPGetter.class);
	
	public static String vipPath = "/vip/vip.properties";
	
	public static Properties getViPProperties() {
		try {
			return TopsConfClient.getConfProperties(vipPath);
		} catch (Exception e) {
			logger.error("获取会员收费配置错误：", e);
			throw new RuntimeException("获取会员收费配置错误");
		}
	}
	
	public static String getVipId() {
		return getViPProperties().getProperty("id");
	}
	
	public static String getFee() {
		return getViPProperties().getProperty("fee");
	}
	
	public static String getPeriod() {
		return getViPProperties().getProperty("period");
	}

	public static String getDateUnit() {
		return getViPProperties().getProperty("dateUnit");
	}
	
}
