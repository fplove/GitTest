package com.trade.ytrtg.common.information.dto;

public class PortalsRealtimeDTO extends BasicPortalsInformationDTO {

	private static final long serialVersionUID = 1L;

	private String importance;
	
	private String importantFont;
	
	private Boolean onHome;
	
	//更新日期，格式 2016/02/20
	private String updateDateStr;
	
	//更新时间，格式 09:31
	private String updateTimeStr;

	 /**
     *文章内容
     */
    private String content;

	public String getImportance() {
		return importance;
	}

	public void setImportance(String importance) {
		this.importance = importance;
	}

	public String getImportantFont() {
		return importantFont;
	}

	public void setImportantFont(String importantFont) {
		this.importantFont = importantFont;
	}

	public Boolean getOnHome() {
		return onHome;
	}

	public void setOnHome(Boolean onHome) {
		this.onHome = onHome;
	}

	public String getUpdateDateStr() {
		return updateDateStr;
	}

	public void setUpdateDateStr(String updateDateStr) {
		this.updateDateStr = updateDateStr;
	}

	public String getUpdateTimeStr() {
		return updateTimeStr;
	}

	public void setUpdateTimeStr(String updateTimeStr) {
		this.updateTimeStr = updateTimeStr;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
