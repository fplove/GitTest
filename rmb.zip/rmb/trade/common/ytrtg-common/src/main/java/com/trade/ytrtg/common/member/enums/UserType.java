package com.trade.ytrtg.common.member.enums;

/**
 * @author hu
 *
 */
public enum UserType {

	CUSTOMER("会员"),
	EMPLOYEE("员工"),
	ADMIN("超级管理员");
	private String desc;
	
	private UserType(String desc){
		this.desc = desc;
	}
	
	public String desc(){
		return desc;
	}
}
