package com.trade.ytrtg.common.utils;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Node;
import org.jsoup.nodes.TextNode;

/**
 * 文章文本处理工具
 * @author XuMeng
 *
 */
public class ArticleTextUtil {

	/**
	 * 截取一篇带html格式文章的前面部分文章。
	 * @param article 带html格式的文章内容
	 * @param maxLength 截取文章可显示内容的大小，包含空白字符，不包含html标签
	 * @return 文章前面部分文章内容
	 */
	public static String leftArticle(String article, int maxLength) {

		if (StringUtils.isEmpty(article)) {
			return article;
		}
		if (maxLength <= 0) {
			throw new IllegalArgumentException("maxLength 必须大于 0");
		}
		
		Document doc = Jsoup.parse(article);
		left(doc.body(), new StringBuilder(), maxLength);
		return doc.body().html();
	}

	private static void left(Node node, StringBuilder leftText, int maxLength) {
		
		if (node instanceof TextNode) {
			String text = ((TextNode) node).getWholeText();
			int endIndex = maxLength - leftText.length();
			if (endIndex < text.length()) {
				text = text.substring(0, endIndex);
				((TextNode) node).text(text);
			}
			leftText.append(text);
			return;
		}
		
		List<Node> nodes = node.childNodes();
		for (int i = 0; i < nodes.size();) {
			if (leftText.length() >= maxLength) {
				nodes.get(i).remove();
			} else {
				left(nodes.get(i++), leftText, maxLength);
			}
		}
	}
}
