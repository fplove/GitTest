package com.trade.ytrtg.common.member.dto;

import java.io.Serializable;

/**  
 *  
 * @author lewis.yang  
 */
public class DepartmentDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6067274580073435491L;
	
	/**
	 * 部门Id
	 */
	private String id;
	
	/**
	 * 部门名称
	 */
	private String departmentName;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	
}
