package com.trade.ytrtg.common.member.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author hu
 *
 */
public class UserSessionDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7071270266386252124L;

	/**
     *用户ID
     */
    private String id;

    /**
     *用户名
     */
    private String username;

    /**
     *邮箱
     */
    private String email;

    /**
     *手机号码
     */
    private String phone;

    /**
     *密码
     */
    private String password;

    /**
     *用户姓名
     */
    private String realName;

    /**
     *所属部门
     */
    private String departmentId;

    /**
     *岗位名称
     */
    private String postId;

    /**
     *状态
     */
    private String state;

    /**
     *注册时间
     */
    private Date registerTime;

    /**
     *更新时间
     */
    private Date updateTime;

    /**
     *会员等级
     */
    private String vipLevel;

    /**
     *交易员等级
     */
    private String traderLevel;
    
    /**
     *权限
     */
    private String permissions;
    /**
     *是否已登陆
     */
    private Boolean signedin;

    /**
     *最后登陆时间
     */
    private Date signinTime;

    /**
     *最后登陆Ip
     */
    private String signinIp;
    /**
     *标记,用于记住密码
     */
    private String token;
    
    /**
     * 用户类型
     */
    private String userType;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Date getRegisterTime() {
		return registerTime;
	}

	public void setRegisterTime(Date registerTime) {
		this.registerTime = registerTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getVipLevel() {
		return vipLevel;
	}

	public void setVipLevel(String vipLevel) {
		this.vipLevel = vipLevel;
	}

	public String getTraderLevel() {
		return traderLevel;
	}

	public void setTraderLevel(String traderLevel) {
		this.traderLevel = traderLevel;
	}

	public String getPermissions() {
		return permissions;
	}

	public void setPermissions(String permissions) {
		this.permissions = permissions;
	}

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public String getPostId() {
		return postId;
	}

	public void setPostId(String postId) {
		this.postId = postId;
	}

	public Boolean getSignedin() {
		return signedin;
	}

	public void setSignedin(Boolean signedin) {
		this.signedin = signedin;
	}

	public Date getSigninTime() {
		return signinTime;
	}

	public void setSigninTime(Date signinTime) {
		this.signinTime = signinTime;
	}

	public String getSigninIp() {
		return signinIp;
	}

	public void setSigninIp(String signinIp) {
		this.signinIp = signinIp;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}
}
