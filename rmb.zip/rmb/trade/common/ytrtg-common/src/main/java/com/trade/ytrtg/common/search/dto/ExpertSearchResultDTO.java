package com.trade.ytrtg.common.search.dto;

import java.io.Serializable;

/**  
 *  
 * @author lewis.yang  
 */
public class ExpertSearchResultDTO implements Serializable{

	private static final long serialVersionUID = 4708956679676963546L;
	
	private String expertId;
	
	private String expertName;
	
	private String expertReputation;

	public String getExpertId() {
		return expertId;
	}

	public void setExpertId(String expertId) {
		this.expertId = expertId;
	}

	public String getExpertName() {
		return expertName;
	}

	public void setExpertName(String expertName) {
		this.expertName = expertName;
	}

	public String getExpertReputation() {
		return expertReputation;
	}

	public void setExpertReputation(String expertReputation) {
		this.expertReputation = expertReputation;
	}
	

}
