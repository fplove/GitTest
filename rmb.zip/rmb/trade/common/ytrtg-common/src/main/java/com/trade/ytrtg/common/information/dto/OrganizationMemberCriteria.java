package com.trade.ytrtg.common.information.dto;

import com.trade.ytrtg.common.dto.PaginationCriteria;

public class OrganizationMemberCriteria extends PaginationCriteria {

	private static final long serialVersionUID = 5112242456587633736L;

	private String name;
	
	private String keyword;

	private String order = "update_time desc";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}
	
}
