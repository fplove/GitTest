package com.trade.ytrtg.common.bankgate.dto;

import java.io.Serializable;
import java.util.List;

/**
 * 请求银行支付的响应
 * @author renshui
 *
 */
public class ReqBankPayResponse implements Serializable{
	
	private static final long serialVersionUID = -8711777477162510369L;
	
	// 银行支付url
	private String bankPayUrl;
	// 银行支付参数
	private List<ReqBankParam> bankParams;
	
	public String getBankPayUrl() {
		return bankPayUrl;
	}
	public void setBankPayUrl(String bankPayUrl) {
		this.bankPayUrl = bankPayUrl;
	}
	public List<ReqBankParam> getBankParams() {
		return bankParams;
	}
	public void setBankParams(List<ReqBankParam> bankParams) {
		this.bankParams = bankParams;
	}

}
