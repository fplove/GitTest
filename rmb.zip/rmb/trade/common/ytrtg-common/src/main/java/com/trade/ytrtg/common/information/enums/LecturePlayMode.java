package com.trade.ytrtg.common.information.enums;

public enum LecturePlayMode {

	HANDOUT_LECTURE("讲义"),
	VIDEO_LECTURE("视频"),
	LIVE_LECTURE("直播"),
	OFFLINE_LECTURE("线下");
	private String desc;
	
	private LecturePlayMode(String desc) {
		this.setDesc(desc);
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String desc() {
		return desc;
	}
}
