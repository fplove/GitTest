package com.trade.ytrtg.common.member.dto;

import java.io.Serializable;

/**
 * @author hu
 *
 */
public class EmployeeRegisterDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1012679501291329935L;

	/**
    *用户ID
    */
    private String id;
    
    /**
    *邮箱
    */
    private String email;

    /**
    *用户姓名
    */
    private String realName;
    
    /**
     * 员工编号
     */
    private String employeeNo;
    
	/**
	*所属部门
	*/
	private String departmentId;
	
	/**
	*岗位名称
	*/
	private String postId;
	
	/**
    *权限
    */
    private String permissions;
    
    /**
     * 部门名称
     */
    private String department;
    
    /**
     * 岗位名称
     */
    private String postName;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmployeeNo() {
		return employeeNo;
	}

	public void setEmployeeNo(String employeeNo) {
		this.employeeNo = employeeNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}
	
	public String getPermissions() {
		return permissions;
	}

	public void setPermissions(String permissions) {
		this.permissions = permissions;
	}

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public String getPostId() {
		return postId;
	}

	public void setPostId(String postId) {
		this.postId = postId;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getPostName() {
		return postName;
	}

	public void setPostName(String postName) {
		this.postName = postName;
	}
	
}
