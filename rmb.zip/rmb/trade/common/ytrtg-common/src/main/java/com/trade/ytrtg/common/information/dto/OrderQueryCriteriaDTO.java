package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import com.travelzen.framework.core.time.DateTimeUtil;

/**  
 *  
 * @author lewis.yang  
 */
public class OrderQueryCriteriaDTO implements Serializable{
	
	private static final long serialVersionUID = 5618184072151078124L;

	// 订单所有者
	private String userId;
	
	private String userEmail;
	
	// 订单号
	private String orderId;
	
	// 支付渠道
	private String payChannel;
	
	// 订单状态
	private String orderState;
	
	// 关键字
	private String keyword;
	
	private String orderTimeStart;
	
	private String orderTimeEnd;
	
	private Date startTime;
	
	private Date endTime;
	
	private int page;
	
	private int pageSize;
	
	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getPayChannel() {
		return payChannel;
	}

	public void setPayChannel(String payChannel) {
		this.payChannel = payChannel;
	}

	public String getOrderState() {
		return orderState;
	}

	public void setOrderState(String orderState) {
		this.orderState = orderState;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getOrderTimeStart() {
		return orderTimeStart;
	}

	public void setOrderTimeStart(String orderTimeStart) {
		this.orderTimeStart = orderTimeStart;
	}

	public String getOrderTimeEnd() {
		return orderTimeEnd;
	}

	public void setOrderTimeEnd(String orderTimeEnd) {
		this.orderTimeEnd = orderTimeEnd;
	}

	public Date getSTime(){
		if(StringUtils.isNotBlank(getOrderTimeStart()))
			return DateTimeUtil.parseDate10(getOrderTimeStart()).toDate();
		return null;
	}
	
	public Date getETime(){
		if(StringUtils.isNotBlank(getOrderTimeEnd()))
			return DateTimeUtil.parseDate10(getOrderTimeEnd()).toDate();
		return null;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Date getStartTime() {
		return startTime;
	}

	public Date getEndTime() {
		return endTime;
	}
}
