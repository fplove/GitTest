package com.trade.ytrtg.common.information.dto;

public class PortalsNewsSummaryDTO extends BasicPortalsInformationDTO {

	private static final long serialVersionUID = 1L;

	private String pictureMediaId;
	
	private Integer likes;

	public String getPictureMediaId() {
		return pictureMediaId;
	}

	public void setPictureMediaId(String pictureMediaId) {
		this.pictureMediaId = pictureMediaId;
	}

	public Integer getLikes() {
		return likes;
	}

	public void setLikes(Integer likes) {
		this.likes = likes;
	}

}
