package com.trade.ytrtg.common.member.enums;

/**
 * @author tangyihong
 *
 */
public enum VipLevel {

//	V1("会员V1"),
//	V2("会员V2");
	V1("普通会员"),
	V2("高级会员");
	private String desc;
	
	private VipLevel(String desc){
		this.desc = desc;
	}
	
	public String desc(){
		return desc;
	}
}
