package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;

public class TotalPageViewDTO implements Serializable {

	private static final long serialVersionUID = -8492434179952648555L;

	private String informationId;
	
	private Long totalPageView;

	public String getInformationId() {
		return informationId;
	}

	public void setInformationId(String informationId) {
		this.informationId = informationId;
	}

	public Long getTotalPageView() {
		return totalPageView;
	}

	public void setTotalPageView(Long totalPageView) {
		this.totalPageView = totalPageView;
	}
	
}
