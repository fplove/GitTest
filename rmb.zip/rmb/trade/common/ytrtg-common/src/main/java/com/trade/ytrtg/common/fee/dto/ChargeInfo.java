package com.trade.ytrtg.common.fee.dto;

import java.io.Serializable;

/**
 * @author hu
 *
 */
public class ChargeInfo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2240269467872414871L;

	private boolean needCharge;
	
	private boolean isVip2;
	
	private boolean isLogin;
	
	private Long vipFee;
	
	private String vipFeeDesc;
	
	private Long extraFee;
	
	private String extraFeeDesc;
	
	private Long singleFee;
	
	private String singleFeeDesc;

	public boolean isNeedCharge() {
		return needCharge;
	}

	public void setNeedCharge(boolean needCharge) {
		this.needCharge = needCharge;
	}

	public boolean isVip2() {
		return isVip2;
	}

	public void setVip2(boolean isVip2) {
		this.isVip2 = isVip2;
	}

	public boolean isLogin() {
		return isLogin;
	}

	public void setLogin(boolean isLogin) {
		this.isLogin = isLogin;
	}

	public Long getVipFee() {
		return vipFee;
	}

	public void setVipFee(Long vipFee) {
		this.vipFee = vipFee;
	}

	public String getVipFeeDesc() {
		return vipFeeDesc;
	}

	public void setVipFeeDesc(String vipFeeDesc) {
		this.vipFeeDesc = vipFeeDesc;
	}

	public Long getExtraFee() {
		return extraFee;
	}

	public void setExtraFee(Long extraFee) {
		this.extraFee = extraFee;
	}

	public String getExtraFeeDesc() {
		return extraFeeDesc;
	}

	public void setExtraFeeDesc(String extraFeeDesc) {
		this.extraFeeDesc = extraFeeDesc;
	}

	public Long getSingleFee() {
		return singleFee;
	}

	public void setSingleFee(Long singleFee) {
		this.singleFee = singleFee;
	}

	public String getSingleFeeDesc() {
		return singleFeeDesc;
	}

	public void setSingleFeeDesc(String singleFeeDesc) {
		this.singleFeeDesc = singleFeeDesc;
	}
	
}
