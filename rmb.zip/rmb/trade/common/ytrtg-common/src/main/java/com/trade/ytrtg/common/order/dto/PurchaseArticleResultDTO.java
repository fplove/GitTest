package com.trade.ytrtg.common.order.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author hu
 *
 */
public class PurchaseArticleResultDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7112493179474529831L;

	/**
     *主键
     */
    private String id;

    /**
     *用户id
     */
    private String userId;

    /**
     *文章id
     */
    private String articleId;

    /**
     *费用类型:额外费用或者单篇费用
     */
    private String feeType;

    /**
     *创建时间
     */
    private Date createTime;

    /**
     *更新时间
     */
    private Date updateTime;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getArticleId() {
		return articleId;
	}

	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}

	public String getFeeType() {
		return feeType;
	}

	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
}
