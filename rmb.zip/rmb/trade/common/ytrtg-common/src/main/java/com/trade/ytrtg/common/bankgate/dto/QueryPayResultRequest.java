package com.trade.ytrtg.common.bankgate.dto;

import java.io.Serializable;

/**
 * 查询支付结果的请求
 * @author renshui
 *
 */
public class QueryPayResultRequest implements Serializable{
	
	private static final long serialVersionUID = 4139318044172670809L;
	// 业务系统id
	private String businessSystemId = "trade";
	// 业务系统产生的流水
	private String businessSeq;
	
	public String getBusinessSystemId() {
		return businessSystemId;
	}
	public void setBusinessSystemId(String businessSystemId) {
		this.businessSystemId = businessSystemId;
	}
	public String getBusinessSeq() {
		return businessSeq;
	}
	public void setBusinessSeq(String businessSeq) {
		this.businessSeq = businessSeq;
	}

}
