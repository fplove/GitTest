package com.trade.ytrtg.common.member.enums;

public enum MailType {
	
	ACTIVE("激活邮件"),
	RE_ACTIVE("重发激活邮件"),
	RESET_PASSWORD("重置密码");
	
	private String desc;
	
	private MailType(String desc){
		this.desc = desc;
	}
	
	public String desc(){
		return desc;
	}
}
