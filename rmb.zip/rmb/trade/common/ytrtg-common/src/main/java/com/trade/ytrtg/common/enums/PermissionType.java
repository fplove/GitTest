package com.trade.ytrtg.common.enums;

/**
 * 权限的类型
 * @since 2015-11-3 上午11:41:58
 * @author zhiwen.hu
 */
public enum PermissionType{

	MODULE, BUTTON, PERM;
	
}
