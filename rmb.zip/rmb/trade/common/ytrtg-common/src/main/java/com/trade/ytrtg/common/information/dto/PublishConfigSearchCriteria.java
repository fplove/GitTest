package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;

/**
 * @author hu
 *
 */
public class PublishConfigSearchCriteria implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1867496830272938715L;
	/**
     * 页码，从1开始
     */
    private int page = 1;
    
    /**
     * 每页的行数
     */
    private int pageSize;

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}
}
