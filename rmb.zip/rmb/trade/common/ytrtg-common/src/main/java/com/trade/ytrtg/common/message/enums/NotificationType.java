package com.trade.ytrtg.common.message.enums;

/**
 * 通知消息类型
 * @author XuMeng
 *
 */
public enum NotificationType {
    TEST("");

    private String desc;
    NotificationType(String desc) {
        this.desc = desc;
    }
    public String desc() {
        return desc;
    }
    
    public String getDesc() {
        return desc;
    }
}
