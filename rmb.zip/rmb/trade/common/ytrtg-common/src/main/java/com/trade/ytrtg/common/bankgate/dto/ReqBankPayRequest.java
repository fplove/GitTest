package com.trade.ytrtg.common.bankgate.dto;

import java.io.Serializable;

/**
 * 请求银行支付的请求
 * 
 * @author renshui
 *
 */
public class ReqBankPayRequest implements Serializable {

	private static final long serialVersionUID = 8655227587531854925L;

	private String gateSeq; // 网关流水，必须
	private String subject; // 商品名称，必须
	private long amount; // 付款金额，单位为分，必须大于0
	private String summary; // 商品描述，选填

	public String getGateSeq() {
		return gateSeq;
	}

	public void setGateSeq(String gateSeq) {
		this.gateSeq = gateSeq;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public long getAmount() {
		return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

}
