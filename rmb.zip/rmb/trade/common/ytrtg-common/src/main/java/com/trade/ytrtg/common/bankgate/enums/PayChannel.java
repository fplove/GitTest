package com.trade.ytrtg.common.bankgate.enums;

/**
 * @author 支付通道
 *
 */
public enum PayChannel {

	alipay("支付宝"),
	weixin("微信"),
	mock("打转银行");
	
	
	private String desc;
	private PayChannel(String desc){
		this.desc = desc;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String desc() {
		return desc;
	}
	
}
