package com.trade.ytrtg.common.order.enums;

/**
 * 订单支付状态
 */
public enum OrderState {

	handling("待支付"),
	success("支付成功"),
	fail("取消");
	
	private String desc;
	private OrderState(String desc){
		this.desc = desc;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String desc() {
		return desc;
	}
	
}
