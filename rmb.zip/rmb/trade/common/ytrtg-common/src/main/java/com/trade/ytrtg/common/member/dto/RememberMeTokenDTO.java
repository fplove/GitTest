package com.trade.ytrtg.common.member.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author hu
 *
 */
public class RememberMeTokenDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2561692125110845485L;

	/**
     *序列号（主键）
     */
    private String series;

    /**
     *用户名
     */
    private String username;

    /**
     *登陆凭证
     */
    private String token;

    /**
     *上一次登陆使用
     */
    private Date lastUsed;
    
    public RememberMeTokenDTO(){
    	
    }
    
    public RememberMeTokenDTO(String series, String username, String token, Date lastUsed){
    	this.series = series;
    	this.username = username;
    	this.token = token;
    	this.lastUsed = lastUsed;
    }

	public String getSeries() {
		return series;
	}

	public void setSeries(String series) {
		this.series = series;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public Date getLastUsed() {
		return lastUsed;
	}

	public void setLastUsed(Date lastUsed) {
		this.lastUsed = lastUsed;
	}
}
