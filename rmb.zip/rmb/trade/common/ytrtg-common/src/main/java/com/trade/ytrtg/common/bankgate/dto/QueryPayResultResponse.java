package com.trade.ytrtg.common.bankgate.dto;

import java.io.Serializable;

import com.trade.ytrtg.common.bankgate.enums.BankGateTranState;
import com.trade.ytrtg.common.bankgate.enums.PayChannel;
import com.travelzen.framework.core.common.ReturnCode;

/**
 * 查询支付结果的响应
 * @author renshui
 *
 */
public class QueryPayResultResponse implements Serializable{
	
	private static final long serialVersionUID = -4365121212271405592L;

	/**
	 * 查询状态
	 */
	private ReturnCode retCode;
	
	/**
	 * 返回消息
	 */
	private String retMsg;
	
	/**
	 * 交易状态
	 */
	private BankGateTranState state;
	
	/**
	 * 网关的支付流水
	 */
	private String gateSeq;

	private PayChannel payChannel;

	public ReturnCode getRetCode() {
		return retCode;
	}

	public void setRetCode(ReturnCode retCode) {
		this.retCode = retCode;
	}

	public BankGateTranState getState() {
		return state;
	}

	public void setState(BankGateTranState state) {
		this.state = state;
	}

	public String getGateSeq() {
		return gateSeq;
	}

	public void setGateSeq(String gateSeq) {
		this.gateSeq = gateSeq;
	}

	public String getRetMsg() {
		return retMsg;
	}

	public void setRetMsg(String retMsg) {
		this.retMsg = retMsg;
	}

	public PayChannel getPayChannel() {
		return payChannel;
	}

	public void setPayChannel(PayChannel payChannel) {
		this.payChannel = payChannel;
	}
}
