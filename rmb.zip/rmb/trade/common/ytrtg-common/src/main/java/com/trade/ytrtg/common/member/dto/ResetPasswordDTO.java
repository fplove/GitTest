package com.trade.ytrtg.common.member.dto;

import java.io.Serializable;

/**
 * @author hu
 *
 */
public class ResetPasswordDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1642214361856217908L;

	private String userId;
	
	private String password;
	
	private String copyPassword;
	
	private String securityCode;
	
	private String userType;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCopyPassword() {
		return copyPassword;
	}

	public void setCopyPassword(String copyPassword) {
		this.copyPassword = copyPassword;
	}

	public String getSecurityCode() {
		return securityCode;
	}

	public void setSecurityCode(String securityCode) {
		this.securityCode = securityCode;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}
	
}
