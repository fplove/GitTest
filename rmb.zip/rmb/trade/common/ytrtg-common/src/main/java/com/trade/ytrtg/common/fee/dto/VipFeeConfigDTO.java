package com.trade.ytrtg.common.fee.dto;

import java.io.Serializable;

public class VipFeeConfigDTO implements Serializable{

	private static final long serialVersionUID = 1L;
    	
    /**
     *为vip
     */
    private String id;

    /**
     *价格（元）
     */
    private String fee;

    /**
     *有效期
     */
    private String period;

    /**
     * 有效期单位
     */
    private String dateUnit;
    
    /**
     * 有效期单位描述
     */
    private String dateUnitDesc;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFee() {
		return fee;
	}

	public void setFee(String fee) {
		this.fee = fee;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getDateUnit() {
		return dateUnit;
	}

	public void setDateUnit(String dateUnit) {
		this.dateUnit = dateUnit;
	}

	public String getDateUnitDesc() {
		return dateUnitDesc;
	}

	public void setDateUnitDesc(String dateUnitDesc) {
		this.dateUnitDesc = dateUnitDesc;
	}
    
}
