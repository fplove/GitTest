package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;

/**
 * 保存多种频道下的子频道的类
 * @author sugar
 *
 */
public class SubTypeDTO implements Serializable{

	private static final long serialVersionUID = 88225465982089479L;
	
	private String name;
	
	private String desc;

	public SubTypeDTO(String name,String desc){
		this.name = name;
		this.desc = desc;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}
