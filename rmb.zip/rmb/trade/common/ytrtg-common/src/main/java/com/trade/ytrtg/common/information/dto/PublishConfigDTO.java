package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;

import com.google.gson.Gson;
import com.trade.ytrtg.common.information.enums.ChannelType;

/**
 * @author hu
 *
 */
public class PublishConfigDTO implements Serializable{

	private static final long serialVersionUID = -1247281135010093025L;
	
	private String id;
	
	private String channelType;
	
	private Boolean enable;
	
	private BasicPublishConfig data;

	public PublishConfigDTO(){
		
	}
	/**
	 * 转换json数据对象
	 * @param data
	 */
	public PublishConfigDTO(String data, ChannelType channelType){
		this.channelType = channelType.getDesc();
		Gson gson = new Gson();
		switch (channelType){
			case NEWS:
				this.data = gson.fromJson(data, NewsPublishConfig.class);
				break;
			case REALTIMEINFORMATION:
				this.data = gson.fromJson(data, RealTimeInfoPublishConfig.class);
				break;
			case LECTURE:
				this.data = gson.fromJson(data, LecturePublishConfig.class);
				break;
			case RESEARCH:
				this.data = gson.fromJson(data, ResearchPublishConfig.class);
		}
	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getChannelType() {
		return channelType;
	}

	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	public Boolean getEnable() {
		return enable;
	}
	public void setEnable(Boolean enable) {
		this.enable = enable;
	}

	public BasicPublishConfig getData() {
		return data;
	}

	public void setData(BasicPublishConfig data) {
		this.data = data;
	}

	public String getPublishData() {
		Gson gson = new Gson();
		return gson.toJson(data);
	}
}
