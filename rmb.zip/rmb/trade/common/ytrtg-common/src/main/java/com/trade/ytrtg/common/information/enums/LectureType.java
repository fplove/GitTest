package com.trade.ytrtg.common.information.enums;

public enum LectureType {

	LECTURE("交易培训");

	private String desc;
	
	private LectureType(String desc) {
		this.setDesc(desc);
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String desc() {
		return desc;
	}
}
