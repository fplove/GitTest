package com.trade.ytrtg.common.bankgate.dto;

import java.io.Serializable;
import java.util.List;

import com.travelzen.framework.core.common.ReturnCode;

/**
 * 请求支付的响应
 * @author renshui
 *
 */
public class ReqPayResponse implements Serializable{
	
	private static final long serialVersionUID = -8717196668185755258L;
	// 返回码
	private ReturnCode retCode;
	// 返回消息
	private String retMsg;
	// 银行支付url
	private String bankPayUrl;
	// 银行支付参数
	private List<ReqBankParam> bankParams;
	
	public ReturnCode getRetCode() {
		return retCode;
	}
	public void setRetCode(ReturnCode retCode) {
		this.retCode = retCode;
	}
	public String getRetMsg() {
		return retMsg;
	}
	public void setRetMsg(String retMsg) {
		this.retMsg = retMsg;
	}
	public String getBankPayUrl() {
		return bankPayUrl;
	}
	public void setBankPayUrl(String bankPayUrl) {
		this.bankPayUrl = bankPayUrl;
	}
	public List<ReqBankParam> getBankParams() {
		return bankParams;
	}
	public void setBankParams(List<ReqBankParam> bankParams) {
		this.bankParams = bankParams;
	}

}
