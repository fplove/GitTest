package com.trade.ytrtg.common.bankgate.dto;

import java.io.Serializable;

import com.trade.ytrtg.common.bankgate.enums.PayChannel;

/**
 * 请求支付的请求
 * @author renshui
 *
 */
public class ReqPayRequest implements Serializable{
	
	private static final long serialVersionUID = 8729210269377963098L;

	// 业务系统id，默认为trade，目前只有一个
	private String businessSystemId = "trade";
	// 业务系统产生的流水，网关流水号也等于此值，规则为订单号加一个特殊自负，后再跟一个序列号
	private String businessSeq;
	// 业务系统的交易日期，格式：yyyy-MM-dd
	private String tranDate;
	// 支付渠道标识
	private PayChannel payChannel;
	// 支付金额
	private long amount;
	// 页面跳转同步通知页面路径
	private String returnUrl;
	// 服务器异步通知页面路径
	private String notifyUrl;
	
	private String subject; // 商品名称，必须
	private String summary; // 商品描述，选填

	public String getBusinessSystemId() {
		return businessSystemId;
	}
	public void setBusinessSystemId(String businessSystemId) {
		this.businessSystemId = businessSystemId;
	}
	public String getBusinessSeq() {
		return businessSeq;
	}
	public void setBusinessSeq(String businessSeq) {
		this.businessSeq = businessSeq;
	}
	public String getTranDate() {
		return tranDate;
	}
	public void setTranDate(String tranDate) {
		this.tranDate = tranDate;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public String getReturnUrl() {
		return returnUrl;
	}
	public void setReturnUrl(String returnUrl) {
		this.returnUrl = returnUrl;
	}
	public String getNotifyUrl() {
		return notifyUrl;
	}
	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}
	public PayChannel getPayChannel() {
		return payChannel;
	}
	public void setPayChannel(PayChannel payChannel) {
		this.payChannel = payChannel;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	
	

}
