package com.trade.ytrtg.common.utils;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;

public class EntityJsonCovert {

	/** 对象转化为json字符串 */
	public static <T> String bean2Jsonstr(T bean){
		if(null == bean){
			return null;
		}
		Gson gson = new Gson();
		String str = gson.toJson(bean);
		return str;
	}
	
	/** json字符串转化为对象 */
	public static <T> T jsonstr2Bean(String str, Class <T> object){
		Gson gson = new Gson();
		T bean = null;
		if(StringUtils.isNotBlank(str)){
			bean = gson.fromJson(str, object);
		}
		
		return bean;
	}
}
