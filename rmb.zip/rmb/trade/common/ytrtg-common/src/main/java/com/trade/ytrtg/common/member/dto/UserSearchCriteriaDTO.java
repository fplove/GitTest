package com.trade.ytrtg.common.member.dto;

import java.io.Serializable;

/**
 * @author hu
 *
 */
public class UserSearchCriteriaDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1366575455962430908L;

	/**
     *用户姓名
     */
	private String username;
	
	/**
     *会员等级
     */
	private String vipLevel;
	
	/**
     *交易员等级
     */
	private String traderLevel;
	
	/**
     *注册开始时间
     */
    private String registerStartTime;
    
    /**
     *注册结束时间
     */
    private String registerEndTime;

    /**
     * 页码，从1开始
     */
    private int page = 1;
    
    /**
     * 每页的行数
     */
    private int pageSize;
    
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getRegisterStartTime() {
		return registerStartTime;
	}

	public void setRegisterStartTime(String registerStartTime) {
		this.registerStartTime = registerStartTime;
	}

	public String getRegisterEndTime() {
		return registerEndTime;
	}

	public void setRegisterEndTime(String registerEndTime) {
		this.registerEndTime = registerEndTime;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public String getVipLevel() {
		return vipLevel;
	}

	public void setVipLevel(String vipLevel) {
		this.vipLevel = vipLevel;
	}

	public String getTraderLevel() {
		return traderLevel;
	}

	public void setTraderLevel(String traderLevel) {
		this.traderLevel = traderLevel;
	}
}
