package com.trade.ytrtg.common.bankgate.enums;

/**
 * @author 支付通道
 *
 */
public enum TranType {

	pay("支付"),
	refund("退款");
	
	private String desc;
	private TranType(String desc){
		this.desc = desc;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String desc() {
		return desc;
	}
	
}
