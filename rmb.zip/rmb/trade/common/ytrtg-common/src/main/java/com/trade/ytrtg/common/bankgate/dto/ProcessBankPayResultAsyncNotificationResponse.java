package com.trade.ytrtg.common.bankgate.dto;

import java.io.Serializable;

import com.travelzen.framework.core.common.ReturnCode;

public class ProcessBankPayResultAsyncNotificationResponse implements Serializable{

	private static final long serialVersionUID = -1129919937498257241L;
	// 处理结果
	private ReturnCode retCode;
	
	private Ack2Bank ack;

	public ReturnCode getRetCode() {
		return retCode;
	}

	public void setRetCode(ReturnCode retCode) {
		this.retCode = retCode;
	}

	public Ack2Bank getAck() {
		return ack;
	}

	public void setAck(Ack2Bank ack) {
		this.ack = ack;
	}

}
