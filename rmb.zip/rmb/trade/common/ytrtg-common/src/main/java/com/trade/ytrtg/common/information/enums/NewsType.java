package com.trade.ytrtg.common.information.enums;

public enum NewsType {

	LATEST_NEWS("市场热点"),
	RECOMMEND_NEWS("宏观策略");
	
	private String desc;
	
	private NewsType(String desc) {
		this.setDesc(desc);
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String desc() {
		return desc;
	}
	
}
