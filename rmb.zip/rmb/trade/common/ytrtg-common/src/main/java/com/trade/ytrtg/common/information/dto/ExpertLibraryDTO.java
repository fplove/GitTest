package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;

/**  
 *  
 * @author lewis.yang  
 */
public class ExpertLibraryDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6092236735686265302L;

	/**
	 * 专家Id
	 */
	private String id;
	
	/**
	 * 专家姓名
	 */
	private String expertName;
	
	/**
	 * 专家名誉
	 */
	private String reputationName;
	
	/**
	 * 专家职位
	 */
	private String positionName;
	
	/**
	 * 专家类型
	 */
	private String expertType;
	
	/**
	 * 照片Id
	 */
	private String imageId;
	
	/**
     * 专家介绍
     */
    private String expertIntroduction;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getExpertName() {
		return expertName;
	}

	public void setExpertName(String expertName) {
		this.expertName = expertName;
	}

	public String getReputationName() {
		return reputationName;
	}

	public void setReputationName(String reputationName) {
		this.reputationName = reputationName;
	}

	public String getPositionName() {
		return positionName;
	}

	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}

	public String getImageId() {
		return imageId;
	}

	public void setImageId(String imageId) {
		this.imageId = imageId;
	}

	public String getExpertIntroduction() {
		return expertIntroduction;
	}

	public void setExpertIntroduction(String expertIntroduction) {
		this.expertIntroduction = expertIntroduction;
	}

	public String getExpertType() {
		return expertType;
	}

	public void setExpertType(String expertType) {
		this.expertType = expertType;
	}
}
