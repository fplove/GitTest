package com.trade.ytrtg.common.information.enums;

public enum RealtimeImportance {

	GENERAL("一般"),
	IMPORTANT("重要");
	
	private String desc;
	
	private RealtimeImportance(String desc) {
		this.setDesc(desc);
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}
