package com.trade.ytrtg.common.information.dto;

public class ResearchListDTO extends BasicPortalsInformationDTO {

	private static final long serialVersionUID = 1L;
	
	private String meetingTime;
	private String meetingAddress;
	private Boolean held;
	
	 /**
     *总浏览数
     */
    private Long pageViewTotal;


	public String getMeetingTime() {
		return meetingTime;
	}

	public void setMeetingTime(String meetingTime) {
		this.meetingTime = meetingTime;
	}

	public String getMeetingAddress() {
		return meetingAddress;
	}

	public void setMeetingAddress(String meetingAddress) {
		this.meetingAddress = meetingAddress;
	}

	public Boolean getHeld() {
		return held;
	}

	public void setHeld(Boolean held) {
		this.held = held;
	}

	public Long getPageViewTotal() {
		return pageViewTotal;
	}

	public void setPageViewTotal(Long pageViewTotal) {
		this.pageViewTotal = pageViewTotal;
	}

}
