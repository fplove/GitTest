package com.trade.ytrtg.common.message.enums;

public enum MessageType {
	MAIL
}
