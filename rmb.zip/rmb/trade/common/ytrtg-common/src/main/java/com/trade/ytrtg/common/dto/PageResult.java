package com.trade.ytrtg.common.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.trade.ytrtg.common.enums.AjaxResponseStatus;

/**
 * @author hu
 *
 */
public class PageResult <T> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7149093620952079187L;
	
	private int totalNum;
	
	private List<T> data;
	
	private AjaxResponseStatus status;
	
	public PageResult() {
    }

    public PageResult(List<T> data, int totalNum) {
        this.setData(data);
        this.setTotalNum(totalNum);
    }

    public static <T> PageResult<T> success(List<T> data, int totalNum) {
    	PageResult<T> result = new PageResult<>();
		result.setStatus(AjaxResponseStatus.SUCCESS);
		result.setTotalNum(totalNum);
		result.setData(data);
		return result;
	}
    
	public List<T> getData() {
		return data;
	}

	public void setData(List<T> data) {
		this.data = null == data ? new ArrayList<T>() : data;
	}

	public int getTotalNum() {
		return totalNum;
	}

	public void setTotalNum(int totalNum) {
		this.totalNum = totalNum;
	}

	public AjaxResponseStatus getStatus() {
		return status;
	}

	public void setStatus(AjaxResponseStatus status) {
		this.status = status;
	}
	
}
