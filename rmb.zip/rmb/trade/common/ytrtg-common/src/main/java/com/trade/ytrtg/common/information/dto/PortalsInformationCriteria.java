package com.trade.ytrtg.common.information.dto;

import com.trade.ytrtg.common.dto.PaginationCriteria;
import com.trade.ytrtg.common.information.enums.ResearchType;

public class PortalsInformationCriteria extends PaginationCriteria{
	
	private static final long serialVersionUID = 4766217842639016905L;
	
	private String channelTypeStr;//频道
	
	private String tag;//标签（多个之间用逗号）
	
	private String form;//形式（多个之间用逗号）
	
	private String type;//类型（多个之间用逗号）
	
	private String subType;//子频道
	
	private String playModes;//播放形式
	
	private String specialist;//专家id
	
	private String nonSpecialist;//不要专家id等于nonSpecialist的数据
	
	private String importance;//重要性(备忘) 可取值：GENERAL,IMPORTANT;为空或者""不作为条件
	
	private String currentId;//当前展示的信息ID，分页查询会导致数据重复展示
	
	//研究院需要
	private Boolean held;//是否已经召开，为null时表示不限制
	
	private ResearchType researchType;//研究院分类：会议研讨，研究报告
	
	private String authorId;//
	
	private String classification;//研究报告分类，为null时表示不限制
	
	public String getChannelTypeStr() {
		return channelTypeStr;
	}
	public void setChannelTypeStr(String channelTypeStr) {
		this.channelTypeStr = channelTypeStr;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getForm() {
		return form;
	}
	public void setForm(String form) {
		this.form = form;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getSpecialist() {
		return specialist;
	}
	public void setSpecialist(String specialist) {
		this.specialist = specialist;
	}
	public String getImportance() {
		return importance;
	}
	public void setImportance(String importance) {
		this.importance = importance;
	}
	public String getCurrentId() {
		return currentId;
	}
	public void setCurrentId(String currentId) {
		this.currentId = currentId;
	}
	public String getPlayModes() {
		return playModes;
	}
	public void setPlayModes(String playModes) {
		this.playModes = playModes;
	}
	public Boolean getHeld() {
		return held;
	}
	public void setHeld(Boolean held) {
		this.held = held;
	}
	public ResearchType getResearchType() {
		return researchType;
	}
	public void setResearchType(ResearchType researchType) {
		this.researchType = researchType;
	}
	public String getAuthorId() {
		return authorId;
	}
	public void setAuthorId(String authorId) {
		this.authorId = authorId;
	}
	public String getClassification() {
		return classification;
	}
	public void setClassification(String classification) {
		this.classification = classification;
	}
	public String getNonSpecialist() {
		return nonSpecialist;
	}
	public void setNonSpecialist(String nonSpecialist) {
		this.nonSpecialist = nonSpecialist;
	}
	
	
	
}
