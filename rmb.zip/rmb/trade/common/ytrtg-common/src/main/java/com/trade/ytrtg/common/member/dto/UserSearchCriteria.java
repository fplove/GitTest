package com.trade.ytrtg.common.member.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * 作为数据库查询条件对象
 * @author hu
 *
 */
public class UserSearchCriteria implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4565602022156137181L;

	/**
     *用户姓名
     */
	private String username;
	
	/**
     *会员等级
     */
	private String vipLevel;
	
	/**
     *交易员等级
     */
	private String traderLevel;
	
	/**
     *注册开始时间
     */
    private Date registerStartTime;
    
    /**
     *注册结束时间
     */
    private Date registerEndTime;
    
    /**
     *用户ID
     */
     private String id;

     /**
     *用户姓名
     */
     private String realName;

     /**
     *所属部门
     */
     private String departmentId;

     /**
     *岗位
     */
     private String postId;
     
     /**
      * 用户类型
      */
     private String userType;

     /**
     *状态
     */
     private String state;

    /**
     * 页码，从1开始
     */
    private int page = 1;
    
    /**
     * 每页的行数
     */
    private int pageSize;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public Date getRegisterEndTime() {
		return registerEndTime;
	}

	public void setRegisterEndTime(Date registerEndTime) {
		this.registerEndTime = registerEndTime;
	}

	public Date getRegisterStartTime() {
		return registerStartTime;
	}

	public void setRegisterStartTime(Date registerStartTime) {
		this.registerStartTime = registerStartTime;
	}

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public String getPostId() {
		return postId;
	}

	public void setPostId(String postId) {
		this.postId = postId;
	}
	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getVipLevel() {
		return vipLevel;
	}

	public void setVipLevel(String vipLevel) {
		this.vipLevel = vipLevel;
	}

	public String getTraderLevel() {
		return traderLevel;
	}

	public void setTraderLevel(String traderLevel) {
		this.traderLevel = traderLevel;
	}
}
