package com.trade.ytrtg.common.bankgate.enums;

/**
 * @author hu
 *
 */
public enum BankGateTranState {

	init("初始"),
	success("成功"),
	handling("处理中"),
	fail("失败"),
	unknown("未知状态");
	
	private String desc;
	private BankGateTranState(String desc){
		this.desc = desc;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String desc() {
		return desc;
	}
	
}
