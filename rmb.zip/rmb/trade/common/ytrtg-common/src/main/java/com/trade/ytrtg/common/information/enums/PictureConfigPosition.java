package com.trade.ytrtg.common.information.enums;

public enum PictureConfigPosition {

	HOME_CAROUSEL("首页轮播"),
	HOME_NEWS_SEPARATE("首页研究分屏"),
	REALTIME_PICTURE("备忘图片");
	
	private String desc;
	
	private PictureConfigPosition(String desc) {
		this.setDesc(desc);
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String desc() {
		return desc;
	}
}
