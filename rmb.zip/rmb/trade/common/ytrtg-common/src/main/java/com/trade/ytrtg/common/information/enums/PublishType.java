package com.trade.ytrtg.common.information.enums;

public enum PublishType {

	REAL_TIME("实时发布"),
	TIMING("定时发布");
	
	private String desc;
	
	private PublishType(String desc) {
		this.setDesc(desc);
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}
