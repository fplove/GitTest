package com.trade.ytrtg.common.information.dto;

public class LectureListDTO extends BasicInformationListDTO {

	private static final long serialVersionUID = 1L;

	private String coverPhotoMediaId;
	
	private String expertName;

	private String playModesDesc;

	public String getCoverPhotoMediaId() {
		return coverPhotoMediaId;
	}

	public void setCoverPhotoMediaId(String coverPhotoMediaId) {
		this.coverPhotoMediaId = coverPhotoMediaId;
	}

	public String getExpertName() {
		return expertName;
	}

	public void setExpertName(String expertName) {
		this.expertName = expertName;
	}

	public String getPlayModesDesc() {
		return playModesDesc;
	}

	public void setPlayModesDesc(String playModesDesc) {
		this.playModesDesc = playModesDesc;
	}

}
