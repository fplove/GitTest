package com.trade.ytrtg.common.bankgate.dto;

import java.io.Serializable;

import com.trade.ytrtg.common.bankgate.enums.BankGateTranState;

public class ProcessBankPayResultSyncNotificationResponse implements Serializable{

	private static final long serialVersionUID = -6440728073698392405L;
	// 业务系统接收前端通知的地址
	private String returnUrl;
	// 业务系统id
	private String businessSystemId;
	// 业务系统产生的流水
	private String businessSeq;
	// 交易状态
	private BankGateTranState state;
	// 支付网关产生的流水
	private String gateSeq;
	// 签名
	private String sign;
	
	public BankGateTranState getState() {
		return state;
	}
	public void setState(BankGateTranState state) {
		this.state = state;
	}
	public String getGateSeq() {
		return gateSeq;
	}
	public void setGateSeq(String gateSeq) {
		this.gateSeq = gateSeq;
	}
	public String getBusinessSystemId() {
		return businessSystemId;
	}
	public void setBusinessSystemId(String businessSystemId) {
		this.businessSystemId = businessSystemId;
	}
	public String getBusinessSeq() {
		return businessSeq;
	}
	public void setBusinessSeq(String businessSeq) {
		this.businessSeq = businessSeq;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	public String getReturnUrl() {
		return returnUrl;
	}
	public void setReturnUrl(String returnUrl) {
		this.returnUrl = returnUrl;
	}
	
}
