package com.trade.ytrtg.common.member.dto;

import java.io.Serializable;

public class UserOtherBasicInfoDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8261096085346764957L;

	/**
	 * 主键
	 */
	private String id;

	/**
	 * 婚姻状况(已婚,未婚,保密)
	 */
	private String maritalStatus;

	/**
	 * 生日
	 */
	private String birthday;

	/**
	 * 教育状况(在职、学生、自由职业者、无业)
	 */
	private String educationalStatus;

	/**
	 * 教育程度(大专以下、大专、本科、硕士、硕士以上)
	 */
	private String educationalDegree;

	/**
	 * 毕业学校
	 */
	private String graduateSchool;

	/**
	 * 身份证号码
	 */
	private String identityCardNo;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getEducationalStatus() {
		return educationalStatus;
	}

	public void setEducationalStatus(String educationalStatus) {
		this.educationalStatus = educationalStatus;
	}

	public String getEducationalDegree() {
		return educationalDegree;
	}

	public void setEducationalDegree(String educationalDegree) {
		this.educationalDegree = educationalDegree;
	}

	public String getGraduateSchool() {
		return graduateSchool;
	}

	public void setGraduateSchool(String graduateSchool) {
		this.graduateSchool = graduateSchool;
	}

	public String getIdentityCardNo() {
		return identityCardNo;
	}

	public void setIdentityCardNo(String identityCardNo) {
		this.identityCardNo = identityCardNo;
	}

}
