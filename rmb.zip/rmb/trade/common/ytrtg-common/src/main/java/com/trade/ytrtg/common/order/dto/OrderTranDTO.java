package com.trade.ytrtg.common.order.dto;

import java.io.Serializable;

/**
 * 支付使用
 * @author XuMeng
 *
 */
public class OrderTranDTO implements Serializable {

	private String businessSeq; // 即OrderTran.id
	private String orderId;
	private long amount;
	private String tranDate;
	private String subject; // 商品名称，必须
	private String summary; // 商品描述，选填

	private static final long serialVersionUID = 1L;

	public String getBusinessSeq() {
		return businessSeq;
	}

	public void setBusinessSeq(String businessSeq) {
		this.businessSeq = businessSeq;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public long getAmount() {
		return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	public String getTranDate() {
		return tranDate;
	}

	public void setTranDate(String tranDate) {
		this.tranDate = tranDate;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

}
