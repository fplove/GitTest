package com.trade.ytrtg.common.search.dto;

import java.io.Serializable;

/**
 * @author hu
 *
 */
public class InformationSearchCriteria implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3808450187867318121L;

	private String keyword;
	
	private String sortMethod;
	/**
     * 页码，从1开始
     */
    private int page = 1;
    
    /**
     * 每页的行数
     */
    private int pageSize;

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getSortMethod() {
		return sortMethod;
	}

	public void setSortMethod(String sortMethod) {
		this.sortMethod = sortMethod;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
}
