package com.trade.ytrtg.common.order.dto;

import java.io.Serializable;

/**  
 *  
 * @author lewis.yang  
 */
public class PersonalOrderDetailDTO implements Serializable{

	private static final long serialVersionUID = 2439902734989834078L;
	
	private String userId;
	
	private String orderNum;
	
	private String orderAmount;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}

	public String getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(String orderAmount) {
		this.orderAmount = orderAmount;
	}

}
