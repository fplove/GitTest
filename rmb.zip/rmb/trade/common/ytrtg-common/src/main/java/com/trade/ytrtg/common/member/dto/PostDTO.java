package com.trade.ytrtg.common.member.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author hu
 *
 */
public class PostDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 916237484826456362L;

	 /**
     *主键
     */
    private String id;

    /**
     *名称
     */
    private String name;

    /**
     *状态(废弃,正常等)
     */
    private String state;

    /**
     *权限
     */
    private String permissions;

    /**
     *创建时间
     */
    private Date createTime;

    /**
     *更新时间
     */
    private Date updateTime;

    /**
     *所属部门id
     */
    private String departmentId;

    /**
     *部门名称
     */
    private String departmentName;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPermissions() {
		return permissions;
	}

	public void setPermissions(String permissions) {
		this.permissions = permissions;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
}
