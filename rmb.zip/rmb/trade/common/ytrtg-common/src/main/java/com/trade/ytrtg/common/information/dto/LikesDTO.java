package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;

public class LikesDTO implements Serializable {

	private static final long serialVersionUID = 356861306907223109L;

	private String informationId;
	
	private Long likes;

	public String getInformationId() {
		return informationId;
	}

	public void setInformationId(String informationId) {
		this.informationId = informationId;
	}

	public Long getLikes() {
		return likes;
	}

	public void setLikes(Long likes) {
		this.likes = likes;
	}
	
}
