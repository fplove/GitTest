package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;

public class BasicInformationListDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String id;
	
	private String channelType;
	
	private String title;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getChannelType() {
		return channelType;
	}

	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

}
