package com.trade.ytrtg.common.member.enums;

/**
 * @author tangyihong
 *
 */
public enum TraderLevel {

	T1("交易员V1"),
	T2("交易员V2");
	
	private String desc;
	
	private TraderLevel(String desc){
		this.desc = desc;
	}
	
	public String desc(){
		return desc;
	}
}
