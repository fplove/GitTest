package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;
import java.util.List;

public class PictureConfigDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	/**
     *图片位置，主键
     */
    private String picturePosition;

    /**
     *备选的图片mediaId（用英文逗号分隔）
     */
    private String alternativeImageMediaIds;

    /**
     *已选的图片信息
     */
    private List<PictureConfigImageInfoDTO> imageInfos;
	
	public String getAlternativeImageMediaIds() {
		return alternativeImageMediaIds;
	}

	public void setAlternativeImageMediaIds(String alternativeImageMediaIds) {
		this.alternativeImageMediaIds = alternativeImageMediaIds;
	}

	public String getPicturePosition() {
		return picturePosition;
	}

	public void setPicturePosition(String picturePosition) {
		this.picturePosition = picturePosition;
	}

	public List<PictureConfigImageInfoDTO> getImageInfos() {
		return imageInfos;
	}

	public void setImageInfos(List<PictureConfigImageInfoDTO> imageInfos) {
		this.imageInfos = imageInfos;
	}
}