package com.trade.ytrtg.common.information.dto;

import com.trade.ytrtg.common.dto.PaginationCriteria;

public class PortalsNewsSummaryDTOSearchCriteria extends PaginationCriteria {

	private static final long serialVersionUID = 1L;
	
	private String subType;

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}
	
}
