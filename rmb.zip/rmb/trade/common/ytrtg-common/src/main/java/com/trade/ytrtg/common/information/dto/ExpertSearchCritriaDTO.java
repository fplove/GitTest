package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;

/**  
 *  
 * @author lewis.yang  
 */
public class ExpertSearchCritriaDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1295143229361271321L;

	/**
	 * 专家姓名
	 */
	private String expertName;
	
	/**
	 * 专家名誉
	 */
	private String keyword;
	
	private int page;
	
	private int pageSize;
	
	public String getExpertName() {
		return expertName;
	}

	public void setExpertName(String expertName) {
		this.expertName = expertName;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
}
