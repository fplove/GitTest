package com.trade.ytrtg.common.information.dto;

/**
 * @author hu
 *
 */
public class RealTimeInfoPublishConfig extends BasicPublishConfig{

	private static final long serialVersionUID = 1L;

	
	
}
