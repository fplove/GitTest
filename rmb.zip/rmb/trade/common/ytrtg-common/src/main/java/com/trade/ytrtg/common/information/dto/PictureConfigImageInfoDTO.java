package com.trade.ytrtg.common.information.dto;

import java.io.Serializable;

public class PictureConfigImageInfoDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	/**
     *图片mediaId
     */
    private String imageMediaId;
    
    /**
     *嵌入标题
     */
    private String embeddedTitle;

    /**
     *说明文字
     */
    private String embeddedText;

    /**
     *文字链接
     */
    private String textLink;

	public String getImageMediaId() {
		return imageMediaId;
	}

	public void setImageMediaId(String imageMediaId) {
		this.imageMediaId = imageMediaId;
	}

	public String getEmbeddedText() {
		return embeddedText;
	}

	public void setEmbeddedText(String embeddedText) {
		this.embeddedText = embeddedText;
	}

	public String getTextLink() {
		return textLink;
	}

	public void setTextLink(String textLink) {
		this.textLink = textLink;
	}

	public String getEmbeddedTitle() {
		return embeddedTitle;
	}

	public void setEmbeddedTitle(String embeddedTitle) {
		this.embeddedTitle = embeddedTitle;
	}

}