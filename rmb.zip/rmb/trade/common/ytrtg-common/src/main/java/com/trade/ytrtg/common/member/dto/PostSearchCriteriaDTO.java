package com.trade.ytrtg.common.member.dto;

import java.io.Serializable;

/**
 * @author hu
 *
 */
public class PostSearchCriteriaDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7021081103954254272L;
	
	/**
     *所属部门id
     */
    private String departmentId;
    
    /**
     *名称
     */
    private String name;
    
    /**
     * 是否具有权限
     * 
     */
    private boolean hasPermissions;
	
    /**
     * 创建开始时间
     */
    private String createStartTime;
    
    /**
     * 创建结束时间
     */
    private String createEndTime;
	
    /**
     * 页码，从1开始
     */
    private int page = 1;
    
    /**
     * 每页的行数
     */
    private int pageSize;

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isHasPermissions() {
		return hasPermissions;
	}

	public void setHasPermissions(boolean hasPermissions) {
		this.hasPermissions = hasPermissions;
	}

	public String getCreateStartTime() {
		return createStartTime;
	}

	public void setCreateStartTime(String createStartTime) {
		this.createStartTime = createStartTime;
	}

	public String getCreateEndTime() {
		return createEndTime;
	}

	public void setCreateEndTime(String createEndTime) {
		this.createEndTime = createEndTime;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

}
