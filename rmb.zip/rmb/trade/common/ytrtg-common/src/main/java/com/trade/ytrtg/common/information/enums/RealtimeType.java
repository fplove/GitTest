package com.trade.ytrtg.common.information.enums;

public enum RealtimeType {
	
//	INTERNATIONAL_NEWS("国际新闻"),
//	DOMESTIC_NEWS("国内新闻");
	REALTIMEINFORMATION("交易备忘");
	
	private String desc;
	
	private RealtimeType(String desc) {
		this.setDesc(desc);
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String desc() {
		return desc;
	}
	
}
