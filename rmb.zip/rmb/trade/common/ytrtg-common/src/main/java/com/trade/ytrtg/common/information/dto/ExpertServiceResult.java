package com.trade.ytrtg.common.information.dto;

/**  
 *  
 * @author lewis.yang  
 */
public class ExpertServiceResult {

	private String expertId;
	
	private String expertName;
	
	private String expertNamePinyin;
	
	private String reputationName;
	
	private String expertType;
	
	private boolean isNew;
	
	private boolean isEdit;

	private boolean isDeleted ;
	
	public ExpertServiceResult() {
		super();
	}
	

	public ExpertServiceResult(String expertId, String expertName, String expertNamePinyin, String reputationName,
			String expertType, boolean isNew, boolean isEdit, boolean isDeleted) {
		super();
		this.expertId = expertId;
		this.expertName = expertName;
		this.expertNamePinyin = expertNamePinyin;
		this.reputationName = reputationName;
		this.expertType = expertType;
		this.isNew = isNew;
		this.isEdit = isEdit;
		this.isDeleted = isDeleted;
	}

	public String getExpertId() {
		return expertId;
	}

	public void setExpertId(String expertId) {
		this.expertId = expertId;
	}

	public String getExpertName() {
		return expertName;
	}

	public void setExpertName(String expertName) {
		this.expertName = expertName;
	}

	public String getExpertNamePinyin() {
		return expertNamePinyin;
	}

	public void setExpertNamePinyin(String expertNamePinyin) {
		this.expertNamePinyin = expertNamePinyin;
	}

	public String getReputationName() {
		return reputationName;
	}

	public void setReputationName(String reputationName) {
		this.reputationName = reputationName;
	}

	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	public boolean isEdit() {
		return isEdit;
	}

	public void setEdit(boolean isEdit) {
		this.isEdit = isEdit;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getExpertType() {
		return expertType;
	}

	public void setExpertType(String expertType) {
		this.expertType = expertType;
	}
	
}
