package com.trade.bankgate.server.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.trade.bankgate.dao.po.BankgateTrans;
import com.trade.bankgate.server.alipay.config.AlipayConfig;
import com.trade.bankgate.server.alipay.util.AlipayCore;
import com.trade.bankgate.server.alipay.util.AlipayNotify;
import com.trade.ytrtg.common.bankgate.dto.Ack2Bank;
import com.trade.ytrtg.common.bankgate.dto.BankResult;
import com.trade.ytrtg.common.bankgate.dto.ReqBankParam;
import com.trade.ytrtg.common.bankgate.dto.ReqBankPayRequest;
import com.trade.ytrtg.common.bankgate.dto.ReqBankPayResponse;
import com.trade.ytrtg.common.bankgate.enums.BankGateTranState;
import com.travelzen.framework.core.exception.WebException;
import com.travelzen.framework.core.time.DateTimeUtil;
import com.travelzen.framework.core.util.MoneyUtil;
import com.travelzen.framework.security.RSAUtil;

public class AlipayBankHandler implements IBankHandler {
	private static final Logger logger = LoggerFactory.getLogger(AlipayBankHandler.class);
	private static final Gson gson = new Gson();

	private static final String ALIPAY_GATEWAY_NEW = "https://mapi.alipay.com/gateway.do?";

	@Override
	public ReqBankPayResponse reqPay(ReqBankPayRequest request) {
		ReqBankPayResponse response = new ReqBankPayResponse();

		Map<String, String> sParaTemp = new HashMap<>();
		sParaTemp.put("service", AlipayConfig.service);
		sParaTemp.put("partner", AlipayConfig.partner);
		sParaTemp.put("seller_id", AlipayConfig.seller_id);
		sParaTemp.put("_input_charset", AlipayConfig.input_charset);
		sParaTemp.put("payment_type", AlipayConfig.payment_type);
		sParaTemp.put("notify_url", AlipayConfig.notify_url);
		sParaTemp.put("return_url", AlipayConfig.return_url);
		sParaTemp.put("out_trade_no", request.getGateSeq());
		sParaTemp.put("subject", request.getSubject());
		sParaTemp.put("total_fee", MoneyUtil.cent2Yuan(request.getAmount()));
		sParaTemp.put("body", request.getSummary());

		// 除去数组中的空值和签名参数
		Map<String, String> sPara = AlipayCore.paraFilter(sParaTemp);
		// 生成签名结果
		String mysign = buildRequestMysign(sPara);

		// 签名结果与签名方式加入请求提交参数组中
		sPara.put("sign", mysign);
		sPara.put("sign_type", AlipayConfig.sign_type);

		List<ReqBankParam> bankParams = new ArrayList<>();
		for (String name : sPara.keySet()) {
			bankParams.add(ReqBankParam.of(name, sPara.get(name)));
		}
		response.setBankParams(bankParams);

		String bankPayUrl = ALIPAY_GATEWAY_NEW + "_input_charset=" + AlipayConfig.input_charset;
		response.setBankPayUrl(bankPayUrl);

		logger.info("生成支付宝支付参数结果：{}", gson.toJson(response));
		return response;
	}

	/**
	 * 生成签名结果
	 * 
	 * @param sPara
	 *            要签名的数组
	 * @return 签名结果字符串
	 */
	private String buildRequestMysign(Map<String, String> sPara) {
		String prestr = AlipayCore.createLinkString(sPara); // 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
		if (AlipayConfig.sign_type.equals("RSA")) {
			try {
				byte[] mysign = RSAUtil.sign(prestr.getBytes(), AlipayConfig.private_key);
				return new String(mysign);
			} catch (Exception e) {
				logger.error("生成支付宝签名失败", e);
			}
		}
		return "";
	}

	@Override
	public BankResult parseSyncPayResult(Map<String, String> resultParams) {
		boolean verifyResult = AlipayNotify.verify(resultParams);
		if (verifyResult) {
			String outTradeNo = resultParams.get("out_trade_no");
			String tradeNo = resultParams.get("trade_no");
			String tradeStatus = resultParams.get("trade_status");
			String amount = resultParams.get("total_fee");
			BankResult bankResult = new BankResult();
			bankResult.setAmount(MoneyUtil.yuan2Cent(amount));
			bankResult.setGateSeq(outTradeNo);
			if ("TRADE_FINISHED".equals(tradeStatus) || "TRADE_SUCCESS".equals(tradeStatus)) {
				bankResult.setState(BankGateTranState.success);
			} else if ("WAIT_BUYER_PAY".equals(tradeStatus) || "TRADE_PENDING".equals(tradeStatus)) {
				bankResult.setState(BankGateTranState.handling);
			} else if ("TRADE_CLOSED".equals(tradeStatus)) {
				bankResult.setState(BankGateTranState.fail);
			} else {
				bankResult.setState(BankGateTranState.unknown);
			}
			bankResult.setBankSeq(tradeNo);
			bankResult.setBankCheckDate(DateTimeUtil.date10());
			return bankResult;
		} else {
			throw WebException.instance("验证支付宝签名失败");
		}
	}

	@Override
	public BankResult parseAsyncPayResult(Map<String, String> resultParams) {
		return parseSyncPayResult(resultParams);
	}

	@Override
	public Ack2Bank ack2Bank(BankgateTrans tran) {
		Ack2Bank ack = new Ack2Bank();
		ack.setAck("success");
		return ack;
	}

}
