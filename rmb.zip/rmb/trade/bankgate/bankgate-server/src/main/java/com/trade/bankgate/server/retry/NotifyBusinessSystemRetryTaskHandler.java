package com.trade.bankgate.server.retry;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.lang3.StringUtils;

import com.travelzen.framework.retry.dao.po.RetryTask;
import com.travelzen.framework.retry.handler.HandlerStatus;
import com.travelzen.framework.retry.handler.IRetryTaskHandler;
import com.travelzen.framework.spring.web.context.SpringApplicationContext;

public class NotifyBusinessSystemRetryTaskHandler implements IRetryTaskHandler{

	private HttpClient httpClient = SpringApplicationContext.getApplicationContext().getBean("httpClient", HttpClient.class);
	
	public void execute(RetryTask task, final HandlerStatus status) throws Exception{
		GetMethod method = null;
		try{
			method = new GetMethod(task.getData());
			int httpStatus = httpClient.executeMethod(method);
			if (httpStatus != HttpServletResponse.SC_OK)
				throw new RuntimeException("Request fail.Status code " + status);
			String responseBody = StringUtils.trimToEmpty(method.getResponseBodyAsString());
			if(!"success".equals(responseBody))
				throw new RuntimeException("响应报文体不为success");
		}finally{
			if(method != null)
				method.releaseConnection();
		}
		
	}
	
}
