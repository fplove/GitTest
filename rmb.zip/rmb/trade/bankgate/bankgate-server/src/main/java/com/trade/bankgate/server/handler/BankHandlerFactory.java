package com.trade.bankgate.server.handler;

import com.trade.ytrtg.common.bankgate.enums.PayChannel;

public class BankHandlerFactory {

	
	public static IBankHandler getHandler(PayChannel payChannel){
		
		if(payChannel == PayChannel.alipay)
			return new AlipayBankHandler();
		
		if(payChannel == PayChannel.weixin)
			return new WeixinBankHandler();
		
		if(payChannel == PayChannel.mock)
			return new MockBankHandler();
		
		throw new IllegalArgumentException("不支持此支付通道");
		
	}
	
	public static IBankHandler getHandler(String payChannelId){
		
		return getHandler(PayChannel.valueOf(payChannelId));
		
	}
}
