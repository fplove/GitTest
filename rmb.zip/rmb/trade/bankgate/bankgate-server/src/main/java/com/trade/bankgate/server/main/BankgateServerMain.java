package com.trade.bankgate.server.main;



/**
 * server启动类, 
 * @author renshui
 *
 */
public class BankgateServerMain {
    public static void main(String[] args) {
        com.alibaba.dubbo.container.Main.main(args);
    }
}
