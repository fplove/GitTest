package com.trade.bankgate.server.wechatpay.common;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.trade.ytrtg.common.utils.WebEnv;
import com.travelzen.framework.config.tops.TopsConfEnum.ConfScope;
import com.travelzen.framework.config.tops.TopsConfReader;

@Component
public class Configure {
	
	private static final Logger logger = LoggerFactory.getLogger(Configure.class);

	// key
	public static String key;
		
	// 短信配置文件路径
	public static String WE_CHAT_PAY_PROP_PATH = "properties/wechatPay.properties";

	// 微信分配的公众号ID
	public static String appID ;

	// 微信支付分配的商户号ID
	public static String mchID;

	// 受理模式下给子商户分配的子商户号
	public static String subMchID;
		
	// 交易类型
	public static String tradeType = "NATIVE";

	// 通知地址
	//TODO
	public static String notifyUrl = WebEnv.getPortalsPlatformPath()+"/payment/weixin/notify";
		
	// 终端IP
	public static String spbillCreateIp;
		
	//连接超时时间，默认10秒
	public static int socketTimeout = 10000;

	//传输超时时间，默认30秒
	public static int connectTimeout = 30000;

	// 统一下单API
	public static String PAY_API = "https://api.mch.weixin.qq.com/pay/unifiedorder";

	// 订单查询API
	public static String PAY_QUERY_API = "https://api.mch.weixin.qq.com/pay/orderquery";

	// 关闭订单API
	public static String CLOSE_ORDER_API = "https://api.mch.weixin.qq.com/pay/closeorder";

	// 申请退款API(需要证书)
	public static String REFUND_API = "https://api.mch.weixin.qq.com/secapi/pay/refund";

	// 退款查询API
	public static String REFUND_QUERY_API = "https://api.mch.weixin.qq.com/pay/refundquery";

	//HTTPS证书的本地路径
	private static String certLocalPath = "/opt/conf/yt-data/global/properties/apiclient_cert.p12";

	//HTTPS证书密码，默认密码等于商户号MCHID
	private static String certPassword = "";

	//是否使用异步线程的方式来上报API测速，默认为异步模式
	private static boolean useThreadToDoReport = true;

	public static boolean isUseThreadToDoReport() {
		return useThreadToDoReport;
	}

	public static void setUseThreadToDoReport(boolean useThreadToDoReport) {
		Configure.useThreadToDoReport = useThreadToDoReport;
	}

	public static String HttpsRequestClassName = "com.trade.bankgate.server.wechatpay.common.HttpsRequest";

	public static void setKey(String key) {
		Configure.key = key;
	}

	public static void setAppID(String appID) {
		Configure.appID = appID;
	}

	public static void setMchID(String mchID) {
		Configure.mchID = mchID;
	}

	public static void setSubMchID(String subMchID) {
		Configure.subMchID = subMchID;
	}

	public static void setCertLocalPath(String certLocalPath) {
		Configure.certLocalPath = certLocalPath;
	}

	public static void setCertPassword(String certPassword) {
		Configure.certPassword = certPassword;
	}

	public static String getKey(){
		return key;
	}
	
	public static String getAppid(){
		return appID;
	}
	
	public static String getMchid(){
		return mchID;
	}

	public static String getSubMchid(){
		return subMchID;
	}
	
	public static String getCertLocalPath(){
		return certLocalPath;
	}
	
	public static String getCertPassword(){
		return certPassword;
	}

	public static void setHttpsRequestClassName(String name){
		HttpsRequestClassName = name;
	}

	static{
		Configure.key = StringUtils.trimToEmpty(TopsConfReader.getConfContent(WE_CHAT_PAY_PROP_PATH, "key", ConfScope.G));
		
		Configure.appID = StringUtils.trimToEmpty(TopsConfReader.getConfContent(WE_CHAT_PAY_PROP_PATH, "appid", ConfScope.G));
		logger.info("appID --> {}", Configure.appID);
		
		Configure.mchID = StringUtils.trimToEmpty(TopsConfReader.getConfContent(WE_CHAT_PAY_PROP_PATH, "mchid", ConfScope.G));
		logger.info("mchID --> {}", Configure.mchID);
		
		Configure.subMchID = StringUtils.trimToEmpty(TopsConfReader.getConfContent(WE_CHAT_PAY_PROP_PATH, "submchid", ConfScope.G));
		logger.info("subMchID --> {}", Configure.subMchID);

		Configure.spbillCreateIp = StringUtils.trimToEmpty(TopsConfReader.getConfContent(WE_CHAT_PAY_PROP_PATH, "spbillcreateip", ConfScope.G));
		logger.info("spbillCreateIp --> {}", Configure.spbillCreateIp);
		
		Configure.certPassword = StringUtils.trimToEmpty(TopsConfReader.getConfContent(WE_CHAT_PAY_PROP_PATH, "certpassword", ConfScope.G));
		logger.info("certPassword --> {}", Configure.certPassword);

		Configure.notifyUrl = StringUtils.trimToEmpty(TopsConfReader.getConfContent(WE_CHAT_PAY_PROP_PATH, "notifyurl", ConfScope.G));
		logger.info("notifyUrl --> {}", Configure.notifyUrl);
	}
}
