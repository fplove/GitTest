package com.trade.bankgate.server.handler;

import java.util.Map;

import com.trade.bankgate.dao.po.BankgateTrans;
import com.trade.ytrtg.common.bankgate.dto.Ack2Bank;
import com.trade.ytrtg.common.bankgate.dto.BankResult;
import com.trade.ytrtg.common.bankgate.dto.ReqBankPayRequest;
import com.trade.ytrtg.common.bankgate.dto.ReqBankPayResponse;

public interface IBankHandler {

	/**
	 * 请求支付
	 * @param request
	 * @return
	 */
	public ReqBankPayResponse reqPay(ReqBankPayRequest request);
	
	/**
	 * 解析银行前台返回的支付结果
	 * @param resultParams
	 * @return
	 */
	public BankResult parseSyncPayResult(Map<String, String> resultParams);
	
	/**
	 * 解析银行后台返回的支付结果
	 * @param resultParams
	 * @return
	 */
	public BankResult parseAsyncPayResult(Map<String, String> resultParams);
	
	/**
	 * 处理银行返回的支付结果后给银行的Ack
	 * @param tran
	 * @return
	 */
	public Ack2Bank ack2Bank(BankgateTrans tran);
	
}
