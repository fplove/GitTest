package com.trade.bankgate.server.handler;

import java.util.ArrayList;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Maps;
import com.trade.bankgate.dao.po.BankgateTrans;
import com.trade.bankgate.server.wechatpay.common.Configure;
import com.trade.bankgate.server.wechatpay.common.RandomStringGenerator;
import com.trade.bankgate.server.wechatpay.common.Signature;
import com.trade.bankgate.server.wechatpay.service.ScanPayService;
import com.trade.ytrtg.common.bankgate.dto.Ack2Bank;
import com.trade.ytrtg.common.bankgate.dto.BankResult;
import com.trade.ytrtg.common.bankgate.dto.ReqBankParam;
import com.trade.ytrtg.common.bankgate.dto.ReqBankPayRequest;
import com.trade.ytrtg.common.bankgate.dto.ReqBankPayResponse;
import com.trade.ytrtg.common.bankgate.dto.ScanPayReqData;
import com.trade.ytrtg.common.bankgate.enums.BankGateTranState;
import com.trade.ytrtg.common.utils.XMLParser;
import com.travelzen.framework.core.common.ReturnCode;
import com.travelzen.framework.core.exception.WebException;
import com.travelzen.framework.core.time.DateTimeUtil;

public class WeixinBankHandler implements IBankHandler{

	private static final Logger logger = LoggerFactory.getLogger(WeixinBankHandler.class);
	
	@Override
	public ReqBankPayResponse reqPay(ReqBankPayRequest request) {
		ReqBankPayResponse response = new ReqBankPayResponse();
		
		ScanPayReqData scanPayReqData = new ScanPayReqData();
		scanPayReqData.setAppid(Configure.appID);
		scanPayReqData.setMch_id(Configure.mchID);
		scanPayReqData.setDevice_info("WEB");
		scanPayReqData.setNonce_str(RandomStringGenerator.getRandomStringByLength(16));
		scanPayReqData.setBody(request.getSubject());
		scanPayReqData.setOut_trade_no(request.getGateSeq());
		scanPayReqData.setTotal_fee(request.getAmount());
		scanPayReqData.setSpbill_create_ip(Configure.spbillCreateIp);
		scanPayReqData.setNotify_url(Configure.notifyUrl);
		scanPayReqData.setTrade_type(Configure.tradeType);
		try {
			scanPayReqData.setSign(Signature.getSign(scanPayReqData));
		} catch (IllegalAccessException e) {
			logger.error("未知错误", e);
			throw WebException.instance("未知错误");
		}
		String responseXML = "";
		
		try {
			responseXML = new ScanPayService().request(scanPayReqData);
		} catch (Exception e) {
			logger.error("未知错误", e);
			throw WebException.instance("未知错误");
		} 
		
		if(StringUtils.isBlank(responseXML)){
			throw WebException.instance("请求支付接口失败，请重新发起支付");
		}
		
		String responseSign = "";
		// 获取微信返回签名信息
		try {
			responseSign = Signature.getSignFromResponseString(responseXML);
		} catch (Exception e) {
			logger.error("未知错误", e);
			throw WebException.instance("未知错误");
		} 
		
		// 解析微信返回数据
		Map<String, String> responseMap = Maps.newHashMap();
		try {
			responseMap = XMLParser.getMapFromXML(responseXML);
		} catch (Exception e) {
			logger.error("未知错误", e);
			throw WebException.instance("未知错误");
		} 
		
		// 验签
		String signFromWechat = responseMap.get("sign").toString();
		if(!StringUtils.equals(signFromWechat, responseSign)){
			logger.error("验签失败！");
			throw WebException.instance("验证微信签名失败");
		}
		
		// 验签成功，返回微信支付链接
		if(StringUtils.equals(ReturnCode.SUCCESS.name(), responseMap.get("return_code").toString()) &&
				StringUtils.equals(ReturnCode.SUCCESS.name(), responseMap.get("result_code").toString())){
			ReqBankParam reqBankParam = new ReqBankParam();
			reqBankParam.setParamName("payUrl");
			reqBankParam.setParamValue(responseMap.get("code_url").toString());
			if(null == response.getBankParams()){
				response.setBankParams(new ArrayList<ReqBankParam>());
			}
			response.getBankParams().add(reqBankParam);
		}else{
			throw WebException.instance(responseMap.get("return_msg").toString());
		}
		return response;
	}

	@Override
	public BankResult parseSyncPayResult(Map<String, String> resultParams) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BankResult parseAsyncPayResult(Map<String, String> resultParams) {
		String sign = resultParams.get("sign");
		String signSelf = "";
		resultParams.remove("sign");
		try {
			signSelf = Signature.getSign(resultParams);
		} catch (Exception e) {
			logger.error("未知异常", e);
			throw WebException.instance("验证微信签名失败");
		}
		try {
			if(StringUtils.equals(sign, signSelf)){
				logger.info("微信验签成功...");
				BankResult bankResult = new BankResult();
				bankResult.setAmount(Long.parseLong(resultParams.get("total_fee")));
				bankResult.setBankCheckDate(DateTimeUtil.parseDatetime14(resultParams.get("time_end")).toString("yyyy-MM-dd"));
				bankResult.setBankSeq(resultParams.get("transaction_id"));
				if(StringUtils.equals(resultParams.get("result_code").toString(), ReturnCode.SUCCESS.name())){
					bankResult.setState(BankGateTranState.success);
				}else{
					bankResult.setState(BankGateTranState.fail);
				}
				bankResult.setGateSeq(resultParams.get("out_trade_no"));
				return bankResult;
			}else{
				throw WebException.instance("验证微信签名失败");
			}
		} catch (Exception e) {
			logger.error("未知异常", e);
			throw WebException.instance("验证微信签名失败");
		}
	}

	@Override
	public Ack2Bank ack2Bank(BankgateTrans tran) {
		Ack2Bank ack = new Ack2Bank();
		ack.setAck("success");
		return ack;
	}
}
