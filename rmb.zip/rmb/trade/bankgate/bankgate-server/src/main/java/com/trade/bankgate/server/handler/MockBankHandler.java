package com.trade.bankgate.server.handler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.RandomStringUtils;

import com.trade.bankgate.dao.po.BankgateTrans;
import com.trade.ytrtg.common.bankgate.dto.Ack2Bank;
import com.trade.ytrtg.common.bankgate.dto.BankResult;
import com.trade.ytrtg.common.bankgate.dto.ReqBankParam;
import com.trade.ytrtg.common.bankgate.dto.ReqBankPayRequest;
import com.trade.ytrtg.common.bankgate.dto.ReqBankPayResponse;
import com.trade.ytrtg.common.bankgate.enums.BankGateTranState;

public class MockBankHandler implements IBankHandler{
	
	@Override
	public ReqBankPayResponse reqPay(ReqBankPayRequest request) {
		
		ReqBankPayResponse response = new ReqBankPayResponse();
		response.setBankPayUrl("http://mockBank.com");;
		
		List<ReqBankParam> bankParams = new ArrayList<>();
		bankParams.add(ReqBankParam.of("gateSeq", RandomStringUtils.randomAlphanumeric(10)));
		bankParams.add(ReqBankParam.of("amount", "100000"));
		response.setBankParams(bankParams);
		
		return response;
	}

	@Override
	public BankResult parseSyncPayResult(Map<String, String> resultParams) {
		BankResult bankResult = new BankResult(); 
		
		bankResult.setAmount(Long.parseLong(resultParams.get("amount")));
		bankResult.setBankCheckDate(resultParams.get("bankCheckDate"));
		bankResult.setBankSeq(resultParams.get("bankSeq"));
		bankResult.setGateSeq(resultParams.get("gateSeq"));
		bankResult.setState(BankGateTranState.valueOf(resultParams.get("state")));
		
		return bankResult;
	}

	@Override
	public BankResult parseAsyncPayResult(Map<String, String> resultParams) {
		
		return parseSyncPayResult(resultParams);
		
	}

	@Override
	public Ack2Bank ack2Bank(BankgateTrans tran) {
		Ack2Bank ack = new Ack2Bank();
		ack.setAck("success");
		return ack;
	}


}
