package com.trade.bankgate.server.api.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.trade.bankgate.api.IBankGateApi;
import com.trade.bankgate.dao.mapper.gen.BankgateTransMapper;
import com.trade.bankgate.dao.po.BankgateTrans;
import com.trade.bankgate.dao.po.BankgateTransExample;
import com.trade.bankgate.server.handler.BankHandlerFactory;
import com.trade.bankgate.server.handler.IBankHandler;
import com.trade.bankgate.service.transaction.IBankgateTransactionService;
import com.trade.ytrtg.common.bankgate.dto.BankResult;
import com.trade.ytrtg.common.bankgate.dto.ProcessBankPayResultAsyncNotificationResponse;
import com.trade.ytrtg.common.bankgate.dto.ProcessBankPayResultNotificationRequest;
import com.trade.ytrtg.common.bankgate.dto.ProcessBankPayResultSyncNotificationResponse;
import com.trade.ytrtg.common.bankgate.dto.QueryPayResultRequest;
import com.trade.ytrtg.common.bankgate.dto.QueryPayResultResponse;
import com.trade.ytrtg.common.bankgate.dto.ReqBankPayRequest;
import com.trade.ytrtg.common.bankgate.dto.ReqBankPayResponse;
import com.trade.ytrtg.common.bankgate.dto.ReqPayRequest;
import com.trade.ytrtg.common.bankgate.dto.ReqPayResponse;
import com.trade.ytrtg.common.bankgate.enums.BankGateTranState;
import com.trade.ytrtg.common.bankgate.enums.PayChannel;
import com.trade.ytrtg.common.bankgate.enums.TranType;
import com.trade.ytrtg.common.utils.Constants;
import com.travelzen.framework.core.common.ReturnCode;
import com.travelzen.framework.core.exception.WebException;
import com.travelzen.framework.core.time.DateTimeUtil;
import com.travelzen.framework.dao.rdbms.SequenceGenerator;

public class BankGateApiImpl implements IBankGateApi{
	
	@Resource
	private BankgateTransMapper mapper;
	
	@Resource
	private SequenceGenerator seqGen;
	
	@Resource
	private IBankgateTransactionService transactionService;

	@Override
	public ReqPayResponse reqPay(ReqPayRequest request) {
		
		ReqPayResponse response = new ReqPayResponse();
		
		try{
			checkRequest4reqPay(request);
		}catch(Exception e){
			response.setRetCode(ReturnCode.TP1201);
			response.setRetMsg("参数校验失败：" + e.getMessage());
			return response;
		}
		
		if(existTran(request)){
			response.setRetCode(ReturnCode.TP1202);
			response.setRetMsg("重复交易");
			return response;
		}
		
		
		BankgateTrans trans = insertTran(request);
		
		ReqBankPayResponse  reqBankPayResponse = reqBankPay(trans, request);
		
		//将交易状态更新为支付中
		trans.setState(BankGateTranState.handling.name());
		mapper.updateByPrimaryKeySelective(trans);
		
		response.setRetCode(ReturnCode.SUCCESS);
		response.setRetMsg("请求支付成功");
		response.setBankPayUrl(reqBankPayResponse.getBankPayUrl());
		response.setBankParams(reqBankPayResponse.getBankParams());

		return response;
	}

	/**
	 * 请求银行支付
	 * @param trans
	 * @return
	 */
	private ReqBankPayResponse reqBankPay(BankgateTrans trans, ReqPayRequest payRequest) {
		ReqBankPayRequest request = new ReqBankPayRequest();
		request.setAmount(trans.getAmount());
		request.setGateSeq(trans.getGateSeq());
		request.setSubject(payRequest.getSubject());
		request.setSummary(payRequest.getSummary());
		return BankHandlerFactory.getHandler(trans.getPayChannelId()).reqPay(request);
	}

	private BankgateTrans insertTran(ReqPayRequest request) {
		BankgateTrans trans = new BankgateTrans();
		BeanUtils.copyProperties(request, trans, "pay");
		trans.setId(DateTimeUtil.datetime14() + seqGen.getNextSeq(Constants.BANKGATE_TRANS_ID, 4));
		trans.setGateSeq(request.getBusinessSeq());
		trans.setPayChannelId(request.getPayChannel().name());
		trans.setState(BankGateTranState.init.name());
		trans.setTranType(TranType.pay.name());
		mapper.insertSelective(trans);
		trans = mapper.selectByPrimaryKey(trans.getId());
		return trans;
	}

	private boolean existTran(ReqPayRequest request) {
		BankgateTransExample example = new BankgateTransExample();
		example.createCriteria().andBusinessSeqEqualTo(request.getBusinessSeq())
		                        .andBusinessSystemIdEqualTo(request.getBusinessSystemId());
		return mapper.selectByExample(example).size() > 0;
	}

	/**
	 * 校验请求支付数据有效性
	 * @param request
	 */
	private void checkRequest4reqPay(ReqPayRequest request) throws Exception{
		
		if(request == null)
			throw new Exception("请求为null");
		
		if(StringUtils.isBlank(request.getBusinessSystemId()))
			throw new Exception("businessSystemId不能为空");
		
		if(StringUtils.isBlank(request.getBusinessSeq()))
			throw new Exception("businessSeq不能为空");
		
		if(StringUtils.isBlank(request.getTranDate()))
			throw new Exception("tranDate不能为空");
		
		if(!DateTimeUtil.validateDate10(request.getTranDate()))
			throw new Exception("tranDate的格式不正确");
		
		if(request.getPayChannel() == null)
			throw new Exception("payChannel不能为null");
		
		if(request.getAmount() <= 0)
			throw new Exception("amount必须大于0");
		
		if(StringUtils.isBlank(request.getReturnUrl()))
			throw new Exception("returnUrl不能为空");
		
		if(StringUtils.isBlank(request.getNotifyUrl()))
			throw new Exception("notifyUrl不能为空");
		
		
	}

	@Override
	public QueryPayResultResponse queryPayResult(QueryPayResultRequest request) {
		QueryPayResultResponse response = new QueryPayResultResponse();
		try{
			checkRequest4queryPayResult(request);
		}catch(Exception e){
			response.setRetCode(ReturnCode.TP1201);
			response.setRetMsg("参数校验失败：" + e.getMessage());
			return response;
		}
		
		BankgateTrans bankgateTran = getBankgateTran(request);
		
		if(bankgateTran == null){
			response.setRetCode(ReturnCode.TP1203);
			response.setRetMsg("交易不存在");
			return response;
		}
		
		response.setRetCode(ReturnCode.SUCCESS);
		response.setRetMsg("查询成功");
		response.setState(BankGateTranState.valueOf(bankgateTran.getState()));
		response.setGateSeq(bankgateTran.getGateSeq());
		if (StringUtils.isNotBlank(bankgateTran.getPayChannelId()))
			response.setPayChannel(PayChannel.valueOf(bankgateTran.getPayChannelId()));
		
		return response;
	}

	private BankgateTrans getBankgateTran(QueryPayResultRequest request) {
		
		BankgateTransExample example = new BankgateTransExample();
		example.createCriteria().andBusinessSeqEqualTo(request.getBusinessSeq())
		                        .andBusinessSystemIdEqualTo(request.getBusinessSystemId());
		
		List<BankgateTrans> bankgateTrans = new ArrayList<>();
		bankgateTrans = mapper.selectByExample(example);
		if(CollectionUtils.isEmpty(bankgateTrans))
			return null;
		return bankgateTrans.get(0);
	}

	private void checkRequest4queryPayResult(QueryPayResultRequest request) throws Exception{
		
		if(request == null)
			throw new Exception("请求为null");
		
		if(StringUtils.isBlank(request.getBusinessSystemId()))
			throw new Exception("businessSystemId不能为空");
		
		if(StringUtils.isBlank(request.getBusinessSeq()))
			throw new Exception("businessSeq不能为空");
		
	}

	@Override
	public ProcessBankPayResultSyncNotificationResponse processBankPayResultSyncNotification(
			ProcessBankPayResultNotificationRequest request) {
		
		BankResult bankResult = BankHandlerFactory.getHandler(request.getPayChannelId()).parseSyncPayResult(request.getResultParams());
		
		checkBankResult(bankResult);
		
		BankgateTrans tran = transactionService.updateBankgateTranByBankResult(bankResult);
		
		if(tran.getAmount().longValue() != bankResult.getAmount())
			throw WebException.instance(ReturnCode.ERROR, "金额错误");
		
		ProcessBankPayResultSyncNotificationResponse response = new ProcessBankPayResultSyncNotificationResponse();
		response.setReturnUrl(tran.getReturnUrl());
		response.setBusinessSystemId(tran.getBusinessSystemId());
		response.setBusinessSeq(tran.getBusinessSeq());
		response.setGateSeq(tran.getGateSeq());
		response.setState(BankGateTranState.valueOf(tran.getState()));
		
		return response;
		
	}


	private void checkBankResult(BankResult bankResult) {
		
		if(bankResult == null)
			throw WebException.instance("支付结果为null");
		
		if(StringUtils.isBlank(bankResult.getGateSeq()))
			throw WebException.instance("gateSeq不能为空");
		
		if(StringUtils.isBlank(bankResult.getBankSeq()))
			throw WebException.instance("bankSeq不能为空");
		
		if(StringUtils.isBlank(bankResult.getBankCheckDate()))
			throw WebException.instance("bankCheckDate不能为空");
		
		if(bankResult.getState() == null)
			throw WebException.instance("支付结果中的状态不能为null");
		
	}

	@Override
	public ProcessBankPayResultAsyncNotificationResponse processBankPayResultAsyncNotification(
			ProcessBankPayResultNotificationRequest request) {

		IBankHandler bankHandler = BankHandlerFactory.getHandler(request.getPayChannelId());
		
		BankResult bankResult = bankHandler.parseAsyncPayResult(request.getResultParams());
		
		checkBankResult(bankResult);
		
		BankgateTrans tran = transactionService.updateBankgateTranByBankResult(bankResult);
		
		if(tran.getAmount().longValue() != bankResult.getAmount())
			throw WebException.instance(ReturnCode.ERROR, "金额错误");
		
		ProcessBankPayResultAsyncNotificationResponse response = new ProcessBankPayResultAsyncNotificationResponse();
		
		response.setRetCode(ReturnCode.SUCCESS);
		response.setAck(bankHandler.ack2Bank(tran));
		
		return response;
	}

}
