package com.trade.bankgate.server.wechatpay.service;

import com.trade.bankgate.server.wechatpay.common.Configure;
import com.trade.ytrtg.common.bankgate.dto.ScanPayReqData;

public class ScanPayService extends BaseService{

    public ScanPayService() throws IllegalAccessException, InstantiationException, ClassNotFoundException {
        super(Configure.PAY_API);
    }

    /**
     * 请求支付服务
     * @param scanPayReqData 
     * @return API返回的数据
     * @throws Exception
     */
    public String request(ScanPayReqData scanPayReqData) throws Exception {

        String responseString = sendPost(scanPayReqData);

        return responseString;
    }
}
