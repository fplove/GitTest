package com.trade.bankgate.server.retry;

import org.springframework.stereotype.Service;

import com.travelzen.framework.retry.scheduler.RetryTaskScheduler;

@Service
public class BankgateRetryTaskScheduler extends RetryTaskScheduler{

}
