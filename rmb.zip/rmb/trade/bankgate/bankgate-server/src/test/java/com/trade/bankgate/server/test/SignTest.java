package com.trade.bankgate.server.test;

public class SignTest {

//	@Test
//	public void test() throws Exception {
//		String rsaPrivateKey = AlipayConfig.private_key;
//		String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCopykN9d0DmWdJElPXgEgExXsNuyOP2ICECSSaY12xrDorIlAnwzkMmopcnBrA8eadErOsFgvkFwGDlr3Z4P+QaT+4EaFo0eTDMPjlmgqJCdnPAKmxoK06DA0m8rQmR6LEDObp6bcC/Lc4EY4+wlTT99WEUgCm4AQxOYCtrFCcWQIDAQAB";
//		
//		String plain = "xumeng";
//		String aliSign = RSA.sign(plain, rsaPrivateKey, "utf-8");
//		byte[] tzSign = RSAUtil.sign(plain.getBytes(), rsaPrivateKey);
//		
//		System.out.println(aliSign.equals(new String(tzSign)));
//
//		boolean result = RSAUtil.verify(plain.getBytes(), publicKey, aliSign.getBytes());
//		boolean result2 = RSA.verify("xumeng", new String(tzSign), publicKey, "utf-8");
//		System.out.println(result);
//		System.out.println(result2);
//	}
}
