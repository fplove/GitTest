/**
 * Copyright (c) 2016, Cana and/or its affiliates. All rights reserved.
 */
package com.trade.bankgate.dao.po;

import java.io.Serializable;
import java.util.Date;

public class BankgateTrans implements Serializable {
    /**
     *主键
     */
    private String id;

    /**
     *原流水id,主要用于退款，关联原支付交易
     */
    private String originId;

    /**
     *业务端发起交易的日期， 格式:yyyy-MM-dd
     */
    private String tranDate;

    /**
     *交易类型，如：支付，退款
     */
    private String tranType;

    /**
     *业务系统id
     */
    private String businessSystemId;

    /**
     *业务端产生的流水号
     */
    private String businessSeq;

    /**
     *网关端产生的流水号
     */
    private String gateSeq;

    /**
     *支付渠道id
     */
    private String payChannelId;

    /**
     *银行端产生的流水号
     */
    private String bankSeq;

    /**
     *交易金额
     */
    private Long amount;

    /**
     *银行对账日期, 格式: yyyy-MM-dd
     */
    private String bankCheckDate;

    /**
     *交易状态
     */
    private String state;

    /**
     *页面跳转同步通知页面路径
     */
    private String returnUrl;

    /**
     *服务器异步通知页面路径
     */
    private String notifyUrl;

    /**
     *创建时间
     */
    private Date createTime;

    /**
     *更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    /**
     *主键
     */
    public String getId() {
        return id;
    }

    /**
     *主键
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     *原流水id,主要用于退款，关联原支付交易
     */
    public String getOriginId() {
        return originId;
    }

    /**
     *原流水id,主要用于退款，关联原支付交易
     */
    public void setOriginId(String originId) {
        this.originId = originId == null ? null : originId.trim();
    }

    /**
     *业务端发起交易的日期， 格式:yyyy-MM-dd
     */
    public String getTranDate() {
        return tranDate;
    }

    /**
     *业务端发起交易的日期， 格式:yyyy-MM-dd
     */
    public void setTranDate(String tranDate) {
        this.tranDate = tranDate == null ? null : tranDate.trim();
    }

    /**
     *交易类型，如：支付，退款
     */
    public String getTranType() {
        return tranType;
    }

    /**
     *交易类型，如：支付，退款
     */
    public void setTranType(String tranType) {
        this.tranType = tranType == null ? null : tranType.trim();
    }

    /**
     *业务系统id
     */
    public String getBusinessSystemId() {
        return businessSystemId;
    }

    /**
     *业务系统id
     */
    public void setBusinessSystemId(String businessSystemId) {
        this.businessSystemId = businessSystemId == null ? null : businessSystemId.trim();
    }

    /**
     *业务端产生的流水号
     */
    public String getBusinessSeq() {
        return businessSeq;
    }

    /**
     *业务端产生的流水号
     */
    public void setBusinessSeq(String businessSeq) {
        this.businessSeq = businessSeq == null ? null : businessSeq.trim();
    }

    /**
     *网关端产生的流水号
     */
    public String getGateSeq() {
        return gateSeq;
    }

    /**
     *网关端产生的流水号
     */
    public void setGateSeq(String gateSeq) {
        this.gateSeq = gateSeq == null ? null : gateSeq.trim();
    }

    /**
     *支付渠道id
     */
    public String getPayChannelId() {
        return payChannelId;
    }

    /**
     *支付渠道id
     */
    public void setPayChannelId(String payChannelId) {
        this.payChannelId = payChannelId == null ? null : payChannelId.trim();
    }

    /**
     *银行端产生的流水号
     */
    public String getBankSeq() {
        return bankSeq;
    }

    /**
     *银行端产生的流水号
     */
    public void setBankSeq(String bankSeq) {
        this.bankSeq = bankSeq == null ? null : bankSeq.trim();
    }

    /**
     *交易金额
     */
    public Long getAmount() {
        return amount;
    }

    /**
     *交易金额
     */
    public void setAmount(Long amount) {
        this.amount = amount;
    }

    /**
     *银行对账日期, 格式: yyyy-MM-dd
     */
    public String getBankCheckDate() {
        return bankCheckDate;
    }

    /**
     *银行对账日期, 格式: yyyy-MM-dd
     */
    public void setBankCheckDate(String bankCheckDate) {
        this.bankCheckDate = bankCheckDate == null ? null : bankCheckDate.trim();
    }

    /**
     *交易状态
     */
    public String getState() {
        return state;
    }

    /**
     *交易状态
     */
    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    /**
     *页面跳转同步通知页面路径
     */
    public String getReturnUrl() {
        return returnUrl;
    }

    /**
     *页面跳转同步通知页面路径
     */
    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl == null ? null : returnUrl.trim();
    }

    /**
     *服务器异步通知页面路径
     */
    public String getNotifyUrl() {
        return notifyUrl;
    }

    /**
     *服务器异步通知页面路径
     */
    public void setNotifyUrl(String notifyUrl) {
        this.notifyUrl = notifyUrl == null ? null : notifyUrl.trim();
    }

    /**
     *创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     *创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     *更新时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     *更新时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        BankgateTrans other = (BankgateTrans) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getOriginId() == null ? other.getOriginId() == null : this.getOriginId().equals(other.getOriginId()))
            && (this.getTranDate() == null ? other.getTranDate() == null : this.getTranDate().equals(other.getTranDate()))
            && (this.getTranType() == null ? other.getTranType() == null : this.getTranType().equals(other.getTranType()))
            && (this.getBusinessSystemId() == null ? other.getBusinessSystemId() == null : this.getBusinessSystemId().equals(other.getBusinessSystemId()))
            && (this.getBusinessSeq() == null ? other.getBusinessSeq() == null : this.getBusinessSeq().equals(other.getBusinessSeq()))
            && (this.getGateSeq() == null ? other.getGateSeq() == null : this.getGateSeq().equals(other.getGateSeq()))
            && (this.getPayChannelId() == null ? other.getPayChannelId() == null : this.getPayChannelId().equals(other.getPayChannelId()))
            && (this.getBankSeq() == null ? other.getBankSeq() == null : this.getBankSeq().equals(other.getBankSeq()))
            && (this.getAmount() == null ? other.getAmount() == null : this.getAmount().equals(other.getAmount()))
            && (this.getBankCheckDate() == null ? other.getBankCheckDate() == null : this.getBankCheckDate().equals(other.getBankCheckDate()))
            && (this.getState() == null ? other.getState() == null : this.getState().equals(other.getState()))
            && (this.getReturnUrl() == null ? other.getReturnUrl() == null : this.getReturnUrl().equals(other.getReturnUrl()))
            && (this.getNotifyUrl() == null ? other.getNotifyUrl() == null : this.getNotifyUrl().equals(other.getNotifyUrl()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getOriginId() == null) ? 0 : getOriginId().hashCode());
        result = prime * result + ((getTranDate() == null) ? 0 : getTranDate().hashCode());
        result = prime * result + ((getTranType() == null) ? 0 : getTranType().hashCode());
        result = prime * result + ((getBusinessSystemId() == null) ? 0 : getBusinessSystemId().hashCode());
        result = prime * result + ((getBusinessSeq() == null) ? 0 : getBusinessSeq().hashCode());
        result = prime * result + ((getGateSeq() == null) ? 0 : getGateSeq().hashCode());
        result = prime * result + ((getPayChannelId() == null) ? 0 : getPayChannelId().hashCode());
        result = prime * result + ((getBankSeq() == null) ? 0 : getBankSeq().hashCode());
        result = prime * result + ((getAmount() == null) ? 0 : getAmount().hashCode());
        result = prime * result + ((getBankCheckDate() == null) ? 0 : getBankCheckDate().hashCode());
        result = prime * result + ((getState() == null) ? 0 : getState().hashCode());
        result = prime * result + ((getReturnUrl() == null) ? 0 : getReturnUrl().hashCode());
        result = prime * result + ((getNotifyUrl() == null) ? 0 : getNotifyUrl().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        return result;
    }
}