package com.trade.bankgate.service.transaction.impl;

import java.net.URLEncoder;
import java.util.Date;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.trade.bankgate.dao.mapper.gen.BankgateTransMapper;
import com.trade.bankgate.dao.po.BankgateTrans;
import com.trade.bankgate.dao.po.BankgateTransExample;
import com.trade.bankgate.service.transaction.IBankgateTransactionService;
import com.trade.ytrtg.common.bankgate.dto.BankResult;
import com.trade.ytrtg.common.bankgate.enums.BankGateTranState;
import com.travelzen.framework.retry.dao.mapper.gen.RetryTaskMapper;
import com.travelzen.framework.retry.dao.po.RetryTask;
import com.travelzen.framework.retry.dict.RetryTaskPolicy;
import com.travelzen.framework.retry.dict.RetryTaskState;
import com.travelzen.framework.retry.dict.RetryTaskType;
import com.travelzen.framework.retry.policy.RetryTaskBackOffPolicy;

@Service
public class BankgateTransactionServiceImpl implements IBankgateTransactionService {

	@Resource
	private BankgateTransMapper mapper;
	@Resource
	private RetryTaskMapper retryTaskMapper;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public BankgateTrans updateBankgateTranByBankResult(BankResult bankResult) {
		BankgateTransExample example = new BankgateTransExample();
		example.createCriteria().andGateSeqEqualTo(bankResult.getGateSeq())
				.andStateEqualTo(BankGateTranState.handling.name());

		BankgateTrans newValue = new BankgateTrans();
		newValue.setBankCheckDate(bankResult.getBankCheckDate());
		newValue.setBankSeq(bankResult.getBankSeq());
		newValue.setState(bankResult.getState().name());

		boolean updateSuccess = mapper.updateByExampleSelective(newValue, example) == 1;

		BankgateTrans tran = getBankgateTransByGateSeq(bankResult.getGateSeq());

		if (updateSuccess)
			insertNotifyBusinessSystemRetryTaskRecord(tran);

		return tran;

	}

	private void insertNotifyBusinessSystemRetryTaskRecord(BankgateTrans tran) {
		RetryTask task = new RetryTask();
		task.setTaskType(RetryTaskType.notify_business_system.name());
		task.setTaskId(tran.getBusinessSeq());
		task.setState(RetryTaskState.not_begin.name());
		task.setBackoffPolicy(RetryTaskBackOffPolicy.fixed.name());
		task.setRetryPolicy(RetryTaskPolicy.simple.name());
		task.setFixedBackoffPeriod(10L);
		task.setTaskDeadline(DateUtils.addDays(new Date(), 1));
		task.setData(getNotifyBusinessSystemUrl(tran));
		retryTaskMapper.insertSelective(task);

	}

	private String getNotifyBusinessSystemUrl(BankgateTrans tran) {
		try {
			String notifyUrl = StringUtils.trimToEmpty(tran.getNotifyUrl());
			String parameters = "businessSeq=" + URLEncoder.encode(tran.getBusinessSeq(), "UTF-8");
			if (notifyUrl.contains("?"))
				return notifyUrl + "&" + parameters;
			else
				return notifyUrl + "?" + parameters;
		} catch (Exception e) {
			logger.error("", e);
			return null;
		}
	}

	private BankgateTrans getBankgateTransByGateSeq(String gateSeq) {
		BankgateTransExample example = new BankgateTransExample();
		example.createCriteria().andGateSeqEqualTo(gateSeq);
		return mapper.selectByExample(example).get(0);
	}

}
