package com.trade.bankgate.service.transaction;

import com.trade.bankgate.dao.po.BankgateTrans;
import com.trade.ytrtg.common.bankgate.dto.BankResult;

public interface IBankgateTransactionService {
	
	/**
	 * 根据支付结果更新交易状态
	 * @param bankResult
	 * @return
	 */
	public BankgateTrans updateBankgateTranByBankResult(BankResult bankResult);

}
