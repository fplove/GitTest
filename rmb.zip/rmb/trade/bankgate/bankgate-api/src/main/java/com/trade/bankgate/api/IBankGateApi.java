package com.trade.bankgate.api;

import com.trade.ytrtg.common.bankgate.dto.ProcessBankPayResultAsyncNotificationResponse;
import com.trade.ytrtg.common.bankgate.dto.ProcessBankPayResultNotificationRequest;
import com.trade.ytrtg.common.bankgate.dto.ProcessBankPayResultSyncNotificationResponse;
import com.trade.ytrtg.common.bankgate.dto.QueryPayResultRequest;
import com.trade.ytrtg.common.bankgate.dto.QueryPayResultResponse;
import com.trade.ytrtg.common.bankgate.dto.ReqPayRequest;
import com.trade.ytrtg.common.bankgate.dto.ReqPayResponse;

public interface IBankGateApi {

	/**
	 * 请求支付
	 * @param request
	 * @return
	 */
	public ReqPayResponse reqPay(ReqPayRequest request);
	
	/**
	 * 查询支付结果
	 * @param request
	 * @return
	 */
	public QueryPayResultResponse queryPayResult(QueryPayResultRequest request);
	
	/**
	 * 处理银行支付结果同步通知
	 * @param request
	 * @return
	 */
	public ProcessBankPayResultSyncNotificationResponse processBankPayResultSyncNotification(ProcessBankPayResultNotificationRequest request);
	
	/**
	 * 处理银行支付结果后台异步通知
	 * @param request
	 * @return
	 */
	public ProcessBankPayResultAsyncNotificationResponse processBankPayResultAsyncNotification(ProcessBankPayResultNotificationRequest request);
	
}
