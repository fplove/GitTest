/**
 * Created by yingtian.hong on 2016/4/12.
 * 所有页面公共javascript脚本
 */
$(function(){
    $(".dlg-wrap").on("click", ".dlg-close", function(){
        $(".main-layout").hide();
        $(".dlg-wrap").hide();
    });

    //用户管理
    $("#userBox").bind("mouseenter mouseleave", function(){
        var box = $("#userBox .handleBox");
        if(box.is(":hidden")){
            box.show();
        }else{
            box.hide();
        }
    });

    //单选框
    $(".radioIcon").click(function(){
        $(this).toggleClass("active");
    });

    //单选按钮组
    $(".radioGroup .radioItem").click(function(){
        $(this).addClass("active").siblings().removeClass("active");
    });

    // 下拉列表
    $(".dropdown-menu li a").click(function(){
        var thisHtml = $(this).html();
        var $thisParents = $(this).parents(".dropdown-menu li");
        $(this).parents(".dropdown-menu").siblings(".dropdownBtn").find(".activeFonts").html(thisHtml);
        $thisParents.addClass("active");
        $thisParents.siblings().removeClass("active");
    });

    //单击展开收缩按钮
    $(".personal-infoBox .smallIcon").click(function(){
        if($(this).is(".reduceIcon")){
            $(this).addClass("plusIcon").removeClass("reduceIcon");
            $(this).parents(".personal-infoBox").find("ul").hide();
        }else{
            $(this).addClass("reduceIcon").removeClass("plusIcon");
            $(".personal-infoBox > ul").show();
        }
    });

    /*  单个日历选择框  */
    $("input.datepicker.default").datetimepicker({
        language: "zh-CN",
        format: "yyyy-mm-dd hh:ii",
        autoclose: true,
        todayBtn: 'linked',
        todayHighlight: true,
        weekStart: 0,
        startDate: new Date()
    });

    /* 生日选择 */
    $("input.datepicker.birthday").datetimepicker({
        language: "zh-CN",
        format: "yyyy-mm-dd",
        autoclose: true,
        todayHighlight: true,
        minView: 2,
        weekStart: 0
    });

    /*  时间区间初始化
     注意： 开始和结束时间input元素要放在同一父元素下，即二者要成为兄弟元素
     并且同一父元素下，只能有一对开始-结束时间，否则会影响changeDate时间的赋值
     */
    //  开始时间
    $("input.datepicker.startDate").datetimepicker({
        format: "yyyy-mm-dd",
        language: "zh-CN",
        autoclose: true,
        todayHighlight: true,
        startView: 2,
        minView: 2,
        todayBtn: 'linked',
        startDate: new Date(),
        weekStart: 0,
        setEndDate: $(this).siblings('input.datepicker.endDate').datetimepicker('getDate')
    });

    // 手动清空输入框时，清除对应的时间
    $("input.datepicker.startDate").focus(function(){
        var $endDate = $(this).siblings('input.datepicker.endDate');
        if ($endDate.val() == "") {
            $endDate.datetimepicker("clearDates");
        } else {
            $(this).datetimepicker("setEndDate", $endDate.val());
        }
    });


    //  结束时间
    $("input.datepicker.endDate").datetimepicker({
        format: "yyyy-mm-dd",
        language: "zh-CN",
        autoclose: true,
        todayHighlight: true,
        startView: 2,
        minView: 2,
        todayBtn: 'linked',
        weekStart: 0,
        setStartDate: $(this).siblings('input.datepicker.startDate').datetimepicker('getDate')
    });

    // 手动清空输入框时，清除对应的时间
    $("input.datepicker.endDate").focus(function(){
        var $startDate = $(this).siblings('input.datepicker.startDate');
        if ($startDate.val() == "") {
            $startDate.datetimepicker("clearDates");
        } else {
            $(this).datetimepicker("setStartDate", $startDate.val());
        }
    });
});

/**
 * 自定义弹窗说明：
 * 支持自定义参数有：弹窗宽度，弹窗左上角提示语，弹窗提示信息内容，弹窗显示按钮个数(最多2个)，按钮上显示的文字;
 * 默认弹窗宽度是480px,有4种类型的弹窗，默认显示defaultPop();
 * 所有弹窗都有“左上角提示语”和“右上角关闭按钮”;
 * 调用如：默认弹窗，new popupMg({……自定义参数……}).defaultPop();
 * */
function popupMg(options){
    var setting = {
        width: 480,
        title: "提示",
        message: "操作已完成！",  //默认弹窗信息“操作已完成！”
        DEFAULT: "default",
        CONFIRM: "confirm",
        SUCCESS: "success",
        ERROR: "error",
        WAIT: "wait",
        btnSum: 0, //默认按钮0个按钮
        leftBtn: "确定",  //默认左边按钮显示“确定”
        rightBtn: "取消"  //默认右边按钮显示“取消”
    };
    this.config = $.extend(setting, options);
}

popupMg.prototype = {
    constructor: popupMg,
    //执行函数
    _intoHtml: function(type){
        var _msg = this.config.message,
            _til = this.config.title,
            _btnSum = this.config.btnSum,
            _leftBtn = this.config.leftBtn,
            _rightBtn = this.config.rightBtn,
            head = '<div class="popup-head">' +
                '<span class="popup-title">'+_til+'</span>' +
                '<a class="closeWrap" href="javascript:void(0);">' +
                '<i class="smallIcon closeIcon"></i>'+
                '</a>'+
                '</div>',
            table = '<table><tr>' +
                '<td><span class="popup-icon popup-'+type+'"></span></td>' +
                '<td><span class="popup-info">'+_msg+'</span></td></tr>' +
                '</table>';

        //判断弹窗类型
        if(_btnSum == 0){
            table += '<div class="popup-foot"></div>';
        }else if(_btnSum == 1){
            table += '<div class="popup-foot">' +
                '<a class="submit-link back-link btn-hide" href="javascript:void(0);">'+_leftBtn+'</a>' +
                '</div>';
        } else if(_btnSum == 2){
            table += '<div class="popup-foot">' +
                '<a class="submit-link confirm-link" href="javascript:void(0);">'+_leftBtn+'</a>' +
                '<a class="submit-link back-link btn-hide" href="javascript:void(0);">'+_rightBtn+'</a>' +
                '</div>';
        }else{
            table += "";
        }

        return head+'<div class="popup-content">'+table+'</div>';
    },
    //默认提示弹窗，只显示“左上角提示语”，“右上角关闭按钮”和“弹窗信息内容”
    defaultPop: function(){
        this.showPop(this.config.DEFAULT);
    },
    //确认类型弹窗，显示“左上角提示语”，“右上角关闭按钮”，“两个自定义按钮”
    confirmPop: function(){
        this.showPop(this.config.CONFIRM);
    },
    //成功类型弹窗，显示“左上角提示语”，“右上角关闭按钮”，“一个自定义按钮”
    successPop: function(){
        this.showPop(this.config.SUCCESS);
    },
    //错误类型弹窗，显示“左上角提示语”，“右上角关闭按钮”，“一个自定义按钮”
    errorPop: function(){
        this.showPop(this.config.ERROR);
    },
    //正在加载弹窗，只显示“左上角提示语”，“右上角关闭按钮”和“弹窗信息内容”
    waitPop: function(){
        this.showPop(this.config.WAIT);
    },
    //显示
    showPop: function(type){
        var self = this,
            _type = type ? type:self.config.DEFAULT,
            _msg = self.config.message,
            _til = this.config.title,
            content = self._intoHtml(type);
        var flag = $('.popup-wrap.pop-'+_type+'').length == 0 ? false:true;
        if(flag){
            $('.popup-wrap.pop-'+_type+'').find(".notice-icon").attr("class", "notice-icon popup-"+_type);
            $('.popup-wrap.pop-'+_type+'').find(".popup-info").html(_msg);
            $('.popup-wrap.pop-'+_type+'').find(".popup-title").html(_til);
        }else{
            if($("body").find(".k-overlay").length == 0){
                $("body").append('<div class="main-layout k-overlay"></div>');
            }
            $('<div class="popup-wrap pop-'+_type+'">'+content+'</div>').appendTo("body");

        }
        $(".popup-wrap").css({
            width: function(){
                return self.config.width+"px";
            },
            left: function(){
                return ($(window).width()-self.config.width)/2+"px";
            },
            top: function(){
                return ($(window).height()-$(".popup-wrap").outerHeight())/2+"px";
            }
        });
/*        $(".popup-wrap").bind("click", function(e){
         if($(e.target).is(".btn-hide") || $(e.target).is(".closeWrap")){
         self.hidePop();
         }
         });*/
        $(".btn-hide, .closeWrap").unbind("click");
        $(".btn-hide, .closeWrap").bind("click", function(){
            self.hidePop();
        });
        $('.popup-wrap.pop-'+_type+'').addClass("is-visible");
        $(".k-overlay").css("display", "block");

    },
    //隐藏
    hidePop: function(){
        $(".popup-wrap").removeClass("is-visible");
        $(".k-overlay").css("display", "none");
    }
};

/** 年月日三级联动 **/
(function($){
    $.fn.birthday = function(options){
        var opts = $.extend({}, $.fn.birthday.defaults, options);//整合参数
        var $year = $(this).children("select[name="+ opts.year +"]");
        var $month = $(this).children("select[name="+ opts.month +"]");
        var $day = $(this).children("select[name="+ opts.day +"]");
        MonHead = [31,28,31,30,31,30,31,31,30,31,30,31];
        return this.each(function(){
            var y = new Date().getFullYear();
            var con = "";
            //添加年份
            for(i = y; i >= (y-80); i--){
                con += "<option value='"+i+"'>"+i+"年"+"</option>";
            }
            $year.append(con);
            con = "";
            //添加月份
            for(i = 1;i <= 12; i++){
                con += "<option value='"+i+"'>"+i+"月"+"</option>";
            }
            $month.append(con);
            con = "";
            //添加日期
            var n = MonHead[0];//默认显示第一月
            for(i = 1; i <= n; i++){
                con += "<option value='"+i+"'>"+i+"日"+"</option>";
            }
            $day.append(con);
            $.fn.birthday.change($(this));

        });
    };
    $.fn.birthday.change = function(obj){
        obj.children("select[name="+ $.fn.birthday.defaults.year +"],select[name="+ $.fn.birthday.defaults.month +"]").change(function(){
            var $year = obj.children("select[name="+ $.fn.birthday.defaults.year +"]");
            var $month = obj.children("select[name="+ $.fn.birthday.defaults.month +"]");
            var $day = obj.children("select[name="+ $.fn.birthday.defaults.day +"]");
            $day.empty();
            var selectedYear = $year.find("option:selected").val();
            var selectedMonth = $month.find("option:selected").val();
            if(selectedMonth == 2 && $.fn.birthday.IsRunYear(selectedYear)){//如果是闰年
                var c ="";
                for(var i = 1; i <= 29; i++){
                    c += "<option value='"+i+"'>"+i+"日"+"</option>";
                }
                $day.append(c);
            }else {//如果不是闰年也没选2月份
                var c = "";
                for(var i = 1; i <= MonHead[selectedMonth-1]; i++){
                    c += "<option value='"+i+"'>"+i+"日"+"</option>";
                }
                $day.append(c);
            }
        });
    };
    $.fn.birthday.IsRunYear = function(selectedYear){
        return(0 == selectedYear % 4 && (selectedYear%100 != 0 || selectedYear % 400 == 0));
    };
    $.fn.birthday.defaults = {
        year:"year",
        month:"month",
        day:"day"
    };
})(jQuery);
